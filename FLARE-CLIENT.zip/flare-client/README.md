# FLARE CLIENT (Fabric 1.21.4)

Orange/black PvP client. Java 21, Fabric Loader 0.16.10, Fabric API 0.119.4+1.21.4, Yarn 1.21.4+build.8.

## Build
- GitHub: push the repo, the workflow in `.github/workflows/build.yml` builds it. Download the jar from the run's **Artifacts** (`FLARE-CLIENT`).
- Local: install Gradle 8.12 and JDK 21, run `gradle build`. Jar: `build/libs/flare-client-1.5.0.jar`.
- If Gradle can't resolve the Fabric API version, change `fabric_version` in `gradle.properties` to any `+1.21.4` release.

## Controls
- **Right Shift** opens the ClickGUI (also: pause menu -> "FLARE CLIENT" button, useful on touch launchers).
- Left click toggles a module, right click expands its settings (sliders, modes, colour, keybind).
- Drag panel headers to move them. Mouse wheel scrolls. Type to search.
- Tabs on top: MODULES / HUD EDITOR / CONFIGS. Configs live in `.minecraft/flare/configs/` (`default` autosaves on exit).
- Middle click: friend a player (or throw a pearl). Friends are never targeted. Stored in `flare/friends.txt`.
- DiscordRPC: put your Discord application ID in `flare/discord_client_id.txt`.

## Architecture
```
com.flare.client
 FlareClient            entrypoint: wires Fabric events -> EventBus, loads config
 FriendManager
 event/                 EventBus (@Subscribe, MethodHandles) + events (Tick, PlayerTick, Motion, Packet, Attack, Render2D/3D)
 module/                Module, Category, ModuleManager, HudModule (draggable HUD base)
 module/modules/        combat | movement | render | player | client   (one class per module)
 setting/               Bool, Number, Mode, Color (HSB + rainbow), Keybind
 gui/                   ClickGuiScreen, Panel, ModuleButton, SettingComponent, TopBar, HudEditorScreen,
                        ConfigScreen, FlareTitleScreen, NotificationManager
 util/                  RotationManager (silent rotations + GCD fix), Draw (2D), Render3D, CombatUtil,
                        BlockUtil, InventoryUtil, MoveUtil, PacketUtil, ColorUtil, Anim
 config/                ConfigManager (JSON)
 mixin/                 ClientConnection (packets), ClientPlayerEntity (tick/motion/NoSlow), InteractionManager (attack),
                        PlayerEntity (Reach/NoClip), InGameHud + overlays + GameRenderer (NoRender, Crosshair),
                        LivingEntityRenderer (Nametags), MinecraftClient (title screen + window title)
```
Modules only listen to the bus while enabled, so disabled modules cost nothing.

### Add a module
1. Create a class extending `Module` (or `HudModule`), declare settings with `bool/num/mode/color`.
2. Add `@Subscribe` methods (e.g. `PlayerTickEvent`, `Render3DEvent`).
3. Register it in `ModuleManager.init()`. It shows up in the GUI, config and ArrayList automatically.

### Rotations
Call `RotationManager.INSTANCE.rotate(yaw, pitch, 1)` during `PlayerTickEvent` for silent rotations (camera does not move),
or `snap(yaw, pitch)` to send one look packet right before an interaction. Deltas are snapped to the mouse sensitivity grid.

## Notes
- Written against Yarn 1.21.4 without compiling in the authoring environment. If a build error mentions a renamed method, it is a one-line fix; send the log.
- Risky mixins use `require = 0`, so a mapping mismatch disables that feature instead of crashing the game.
- Use on servers that allow client mods; many servers' rules and anti-cheats prohibit combat modules.

## 1.5.0 changelog
- AutoCrystal: new **Break Mode = Any** (default). It now hits every crystal in range, including ones you place yourself, even with no enemy nearby. "Smart" keeps the old damage-based logic. Auto place still needs an enemy.
- ESP split into **ESP Block** (ore presets + Custom list via `/espblock add|remove|list|clear <block>`, crystals, items), **ESP Player** (3D / Tracer / colour modes) and **ESP Storage** (colour-coded chests, barrels, shulkers by colour, hoppers, droppers, dispensers, furnaces, smokers, bookshelves, crafters; 3D / Tracer toggles).
- New **Freecam** (fly the camera, body stays still, server keeps your old position/rotation).
- New **FPSBoost** (lowers heavy video settings, restores your originals when turned off).
- Nametag background fix.

## 1.5.1
- **Custom Identity** button on the main menu: set your own nickname (offline/cracked servers) and a local 64x64 skin PNG from `.minecraft/flare/skins/`. The skin is visible to you; other players only see it if the server supports it. Nothing is cloned from other accounts.

## 1.5.2
- **Account switching** in Custom Identity: save several custom accounts (nickname + local skin), SWITCH between them from the main menu, delete or add new ones. "(original account)" switches back to your launcher's real name.

## 1.5.3
- Fixed FPSBoost build error (ParticlesMode package).
- New **AntiVanish** (Player): notifies `<name> has been watched you, good luck user flare.` when a player enters spectator mode. Optional experimental vanish detection (player disappears from the tab list without a leave message).
