package com.flare.client.module.modules.movement;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import com.flare.client.util.MoveUtil;
import net.minecraft.entity.effect.StatusEffects;

public class Speed extends Module {
    private final ModeSetting mode = mode("Mode", "Strafe", "Strafe", "BHop", "OnGround", "Vanilla");
    private final NumberSetting speed = num("Speed", 1.2, 0.5, 3.0, 0.05);
    private final BoolSetting autoJump = bool("Auto Jump", true);
    private double cur;
    public Speed() { super("Speed", "Moves faster on the ground and in the air.", Category.MOVEMENT); }

    private double base() {
        double b = 0.2873;
        if (mc.player.hasStatusEffect(StatusEffects.SPEED)) b *= 1.0 + 0.2 * (mc.player.getStatusEffect(StatusEffects.SPEED).getAmplifier() + 1);
        return b * speed.d();
    }

    @Subscribe
    private void onTick(PlayerTickEvent e) {
        var p = mc.player;
        if (p == null || p.isTouchingWater() || p.isInLava() || p.isClimbing() || p.hasVehicle() || p.getAbilities().flying) return;
        if (!MoveUtil.isMoving()) { cur = 0; return; }
        double b = base();
        switch (mode.get()) {
            case "Vanilla" -> MoveUtil.setSpeed(b);
            case "OnGround" -> { if (p.isOnGround()) MoveUtil.setSpeed(b * 1.05); }
            case "BHop" -> {
                if (p.isOnGround()) { if (autoJump.is()) p.jump(); cur = b * 1.55; }
                else cur = Math.max(b * 0.9, cur * 0.985);
                MoveUtil.setSpeed(cur);
            }
            default -> { // Strafe
                if (p.isOnGround()) { if (autoJump.is()) p.jump(); cur = b * 1.35; }
                else cur = Math.max(b, cur * 0.99);
                MoveUtil.setSpeed(cur);
            }
        }
    }
}
