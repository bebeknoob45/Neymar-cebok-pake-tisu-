package com.flare.client.module.modules.combat;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import com.flare.client.util.*;
import net.minecraft.block.Blocks;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;

public class AutoCrystal extends Module {
    private final NumberSetting targetRange = num("Target Range", 10, 4, 16, 1);
    private final NumberSetting placeRange = num("Place Range", 4.5, 2, 6, 0.1);
    private final NumberSetting breakRange = num("Break Range", 4.5, 2, 6, 0.1);
    private final NumberSetting placeDelay = num("Place Delay", 2, 0, 10, 1);
    private final NumberSetting breakDelay = num("Break Delay", 1, 0, 10, 1);
    private final NumberSetting minDmg = num("Min Damage", 4, 0.5, 20, 0.5);
    private final NumberSetting maxSelf = num("Max Self Dmg", 8, 1, 20, 0.5);
    private final NumberSetting facePlace = num("Face Place HP", 8, 0, 36, 1);
    private final ModeSetting breakMode = mode("Break Mode", "Any", "Any", "Smart");
    private final BoolSetting place = bool("Place", true), brk = bool("Break", true), rotate = bool("Rotate", true),
            antiSuicide = bool("Anti Suicide", true), autoSwitch = bool("Auto Switch", true), pauseEat = bool("Pause On Eat", true);
    private int pt, bt; private PlayerEntity target;
    public AutoCrystal() { super("AutoCrystal", "Places and breaks end crystals to damage enemies.", Category.COMBAT); }
    public PlayerEntity getTarget() { return target; }
    @Override protected void onDisable() { target = null; }
    @Override public String getSuffix() { return target != null ? target.getName().getString() : ""; }

    @Subscribe
    private void onTick(PlayerTickEvent e) {
        if (mc.player == null || mc.world == null) return;
        pt++; bt++;
        target = CombatUtil.nearestPlayer(targetRange.d());
        if (pauseEat.is() && mc.player.isUsingItem() && mc.player.getActiveItem().contains(DataComponentTypes.FOOD)) return;
        if (brk.is() && bt >= breakDelay.i()) {
            // "Any": hits every crystal in range (including ones you placed yourself, even with no enemy around).
            EndCrystalEntity c = (target != null && breakMode.is("Smart")) ? bestCrystal() : anyCrystal();
            if (c != null) {
                if (rotate.is()) RotationManager.INSTANCE.snapTo(c.getBoundingBox().getCenter());
                mc.interactionManager.attackEntity(mc.player, c); mc.player.swingHand(Hand.MAIN_HAND); bt = 0;
            }
        }
        if (target != null && place.is() && pt >= placeDelay.i()) {
            BlockPos base = bestPlace();
            if (base != null && doPlace(base)) pt = 0;
        }
    }

    private EndCrystalEntity anyCrystal() {
        EndCrystalEntity best = null; double bd = 999; Vec3d eye = mc.player.getEyePos();
        for (Entity en : mc.world.getEntities()) {
            if (!(en instanceof EndCrystalEntity c) || !c.isAlive()) continue;
            double d = CombatUtil.distanceToBox(eye, c.getBoundingBox());
            if (d > breakRange.d() || d >= bd) continue;
            if (!safe(CombatUtil.crystalDamage(c.getPos(), mc.player))) continue;
            bd = d; best = c;
        }
        return best;
    }

    private float threshold() { return target.getHealth() + target.getAbsorptionAmount() <= facePlace.d() ? 1f : minDmg.f(); }
    private boolean safe(float self) { return self <= maxSelf.d() && (!antiSuicide.is() || self < mc.player.getHealth() + mc.player.getAbsorptionAmount() - 1f); }

    private EndCrystalEntity bestCrystal() {
        EndCrystalEntity best = null; float bs = -999; Vec3d eye = mc.player.getEyePos();
        for (Entity en : mc.world.getEntities()) {
            if (!(en instanceof EndCrystalEntity c) || !c.isAlive()) continue;
            if (CombatUtil.distanceToBox(eye, c.getBoundingBox()) > breakRange.d()) continue;
            Vec3d p = c.getPos();
            float td = CombatUtil.crystalDamage(p, target), sd = CombatUtil.crystalDamage(p, mc.player);
            if (td < threshold() || !safe(sd)) continue;
            float sc = td - sd * 0.5f;
            if (sc > bs) { bs = sc; best = c; }
        }
        return best;
    }

    private BlockPos bestPlace() {
        BlockPos best = null; float bs = -999; Vec3d eye = mc.player.getEyePos(); int r = (int) Math.ceil(placeRange.d());
        BlockPos o = mc.player.getBlockPos();
        for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
            BlockPos b = o.add(x, y, z);
            var st = mc.world.getBlockState(b);
            if (!st.isOf(Blocks.OBSIDIAN) && !st.isOf(Blocks.BEDROCK)) continue;
            BlockPos a = b.up();
            if (!mc.world.isAir(a) || !mc.world.isAir(a.up())) continue;
            if (eye.distanceTo(Vec3d.ofCenter(b).add(0, 0.5, 0)) > placeRange.d()) continue;
            Box box = new Box(a.getX(), a.getY(), a.getZ(), a.getX() + 1, a.getY() + 2, a.getZ() + 1);
            if (!mc.world.getOtherEntities(null, box, en -> !en.isSpectator()).isEmpty()) continue;
            Vec3d cp = new Vec3d(a.getX() + 0.5, a.getY(), a.getZ() + 0.5);
            float td = CombatUtil.crystalDamage(cp, target), sd = CombatUtil.crystalDamage(cp, mc.player);
            if (td < threshold() || !safe(sd)) continue;
            float sc = td - sd * 0.5f;
            if (sc > bs) { bs = sc; best = b; }
        }
        return best;
    }

    private boolean doPlace(BlockPos base) {
        Hand hand;
        if (mc.player.getOffHandStack().isOf(Items.END_CRYSTAL)) hand = Hand.OFF_HAND;
        else if (mc.player.getMainHandStack().isOf(Items.END_CRYSTAL)) hand = Hand.MAIN_HAND;
        else if (autoSwitch.is()) {
            int slot = InventoryUtil.findHotbar(s -> s.isOf(Items.END_CRYSTAL));
            if (slot < 0) return false;
            mc.player.getInventory().selectedSlot = slot; hand = Hand.MAIN_HAND;
        } else return false;
        Vec3d hit = Vec3d.ofCenter(base).add(0, 0.5, 0);
        if (rotate.is()) RotationManager.INSTANCE.snapTo(hit);
        mc.interactionManager.interactBlock(mc.player, hand, new BlockHitResult(hit, Direction.UP, base, false));
        mc.player.swingHand(hand);
        return true;
    }
}
