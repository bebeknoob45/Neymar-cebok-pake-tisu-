package com.flare.client.module.modules.combat;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import com.flare.client.util.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;

public class BowAimbot extends Module {
    private final NumberSetting range = num("Range", 60, 10, 100, 1);
    private final BoolSetting silent = bool("Silent", true), predict = bool("Predict", true), wallCheck = bool("Visible Only", true);
    public BowAimbot() { super("BowAimbot", "Aims your bow with drop and movement prediction.", Category.COMBAT); }

    @Subscribe
    private void onTick(PlayerTickEvent e) {
        var p = mc.player;
        if (p == null || !p.isUsingItem() || !(p.getActiveItem().isOf(Items.BOW) || p.getActiveItem().isOf(Items.CROSSBOW))) return;
        PlayerEntity best = null; double bd = range.d();
        for (PlayerEntity t : mc.world.getPlayers()) {
            if (t == p || !t.isAlive() || t.isSpectator() || CombatUtil.isFriend(t)) continue;
            double d = p.distanceTo(t);
            if (d < bd && (!wallCheck.is() || CombatUtil.canSee(t))) { bd = d; best = t; }
        }
        if (best == null) return;
        float pull = Math.min(1f, p.getItemUseTime() / 20f); pull = (pull * pull + pull * 2f) / 3f;
        double v = p.getActiveItem().isOf(Items.CROSSBOW) ? 3.15 : pull * 3.0;
        if (v < 0.3) return;
        Vec3d eye = p.getEyePos(), tv = new Vec3d(best.getX() - best.prevX, best.getY() - best.prevY, best.getZ() - best.prevZ);
        Vec3d aim = best.getBoundingBox().getCenter(); double ticks = 0; float pitch = 0;
        for (int it = 0; it < 3; it++) {
            Vec3d a = predict.is() ? aim.add(tv.multiply(ticks)) : aim;
            double dx = a.x - eye.x, dz = a.z - eye.z, dy = a.y - eye.y, h = Math.hypot(dx, dz);
            double bestErr = Double.MAX_VALUE; ticks = 0;
            for (double ang = -70; ang <= 70; ang += 0.5) {
                double rad = Math.toRadians(ang), vh = v * Math.cos(rad), vy = v * Math.sin(rad), hh = 0, yy = 0; int n = 0;
                while (hh < h && n < 250) { hh += vh; yy += vy; vh *= 0.99; vy = vy * 0.99 - 0.05; n++; }
                double err = Math.abs(yy - dy);
                if (err < bestErr) { bestErr = err; pitch = (float) -ang; ticks = n; }
            }
        }
        Vec3d fin = predict.is() ? aim.add(tv.multiply(ticks)) : aim;
        float yaw = RotationManager.toRotation(eye, fin)[0];
        if (silent.is()) RotationManager.INSTANCE.rotate(yaw, pitch, 1); else { p.setYaw(yaw); p.setPitch(pitch); }
    }
}
