package com.flare.client.module.modules.render;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.Render3DEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import com.flare.client.util.*;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;

public class Nametags extends Module {
    private final NumberSetting scale = num("Scale", 1.0, 0.5, 2.5, 0.1);
    private final BoolSetting health = bool("Health", true), distance = bool("Distance", true), armor = bool("Armor", true), background = bool("Background", true);
    public Nametags() { super("Nametags", "Custom nametags with health, distance and armor.", Category.RENDER); }

    @Subscribe
    private void onRender(Render3DEvent e) {
        if (mc.world == null) return;
        TextRenderer tr = mc.textRenderer;
        VertexConsumerProvider.Immediate imm = mc.getBufferBuilders().getEntityVertexConsumers();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player && mc.options.getPerspective().isFirstPerson()) continue;
            if (p.isSpectator()) continue;
            Vec3d pos = p.getLerpedPos(e.delta).add(0, p.getHeight() + 0.45, 0);
            double dx = pos.x - e.cam.x, dy = pos.y - e.cam.y, dz = pos.z - e.cam.z, dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            float s = (float) Math.max(0.025, dist * 0.0035) * scale.f();
            MatrixStack ms = new MatrixStack();
            ms.multiplyPositionMatrix(e.view);
            ms.translate(dx, dy, dz);
            ms.multiply(e.camera.getRotation());
            ms.scale(-s, -s, s);

            float hp = p.getHealth() + p.getAbsorptionAmount();
            String name = p.getName().getString(), hs = health.is() ? String.format(" %.1f", hp) : "", ds = distance.is() ? String.format(" %.0fm", mc.player.distanceTo(p)) : "";
            int hc = hp > 14 ? 0xFF55FF55 : hp > 7 ? 0xFFFFAA00 : 0xFFFF5555;
            float w = tr.getWidth(name + hs + ds), x = -w / 2f;
            var m = ms.peek().getPositionMatrix();
            int bg = background.is() ? 0x80000000 : 0;
            int fn = CombatUtil.isFriend(p) ? 0xFF55FF55 : 0xFFFFFFFF;
            tr.draw(name, x, 0, fn, false, m, imm, TextRenderer.TextLayerType.SEE_THROUGH, bg, 0xF000F0); x += tr.getWidth(name);
            if (health.is()) { tr.draw(hs, x, 0, hc, false, m, imm, TextRenderer.TextLayerType.SEE_THROUGH, bg, 0xF000F0); x += tr.getWidth(hs); }
            if (distance.is()) tr.draw(ds, x, 0, 0xFFFF8C00, false, m, imm, TextRenderer.TextLayerType.SEE_THROUGH, bg, 0xF000F0);
            if (armor.is()) {
                StringBuilder sb = new StringBuilder();
                for (EquipmentSlot es : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
                    ItemStack st = p.getEquippedStack(es);
                    sb.append(st.isEmpty() ? "-- " : (st.getMaxDamage() > 0 ? (int) (100f * (st.getMaxDamage() - st.getDamage()) / st.getMaxDamage()) : 100) + " ");
                }
                String as = sb.toString().trim();
                tr.draw(as, -tr.getWidth(as) / 2f, 10, 0xFFFF6B00, false, m, imm, TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
            }
        }
        imm.draw();
    }
}
