package com.flare.client.util;
import net.minecraft.client.util.InputUtil;
public final class KeyUtil {
    public static String name(int key) {
        if (key < 0) return "NONE";
        try { return InputUtil.fromKeyCode(key, 0).getLocalizedText().getString().toUpperCase(); } catch (Throwable t) { return "KEY" + key; }
    }
}
