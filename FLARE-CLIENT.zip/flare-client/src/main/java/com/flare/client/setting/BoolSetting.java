package com.flare.client.setting;
import com.google.gson.*;
public class BoolSetting extends Setting<Boolean> {
    public BoolSetting(String n, boolean d) { super(n, d); }
    public boolean is() { return value; }
    public void toggle() { value = !value; }
    public JsonElement save() { return new JsonPrimitive(value); }
    public void load(JsonElement e) { value = e.getAsBoolean(); }
}
