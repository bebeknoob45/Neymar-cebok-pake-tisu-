package com.flare.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** 2D drawing helpers. All GUI colours go through fade() so whole screens can fade in/out. */
public final class Draw {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public static float alpha = 1f;

    public static int fade(int c) { return (c & 0xFFFFFF) | ((int) (((c >>> 24) & 255) * alpha) << 24); }
    private static boolean invisible(int c) { return ((c >>> 24) & 255) * alpha < 3; }

    public static void rect(DrawContext c, float x, float y, float w, float h, int col) {
        if (invisible(col)) return;
        c.fill(Math.round(x), Math.round(y), Math.round(x + w), Math.round(y + h), fade(col));
    }
    public static void rrect(DrawContext c, float x, float y, float w, float h, float r, int col) {
        if (invisible(col)) return;
        int ix = Math.round(x), iy = Math.round(y), iw = Math.round(w), ih = Math.round(h);
        int ir = (int) Math.min(r, Math.min(iw, ih) / 2f); col = fade(col);
        if (ir <= 0) { c.fill(ix, iy, ix + iw, iy + ih, col); return; }
        c.fill(ix, iy + ir, ix + iw, iy + ih - ir, col);
        for (int i = 0; i < ir; i++) {
            double dy = ir - i - 0.5; int inset = (int) Math.round(ir - Math.sqrt(ir * ir - dy * dy));
            c.fill(ix + inset, iy + i, ix + iw - inset, iy + i + 1, col);
            c.fill(ix + inset, iy + ih - i - 1, ix + iw - inset, iy + ih - i, col);
        }
    }
    public static void glow(DrawContext c, float x, float y, float w, float h, float r, int col, float strength) {
        if (strength <= 0.01f) return;
        for (int i = 1; i <= 6; i++) {
            int a = (int) (((col >>> 24) & 255) * strength * (1f - i / 7f) * 0.30f);
            rrect(c, x - i, y - i, w + 2 * i, h + 2 * i, r + i, (col & 0xFFFFFF) | (a << 24));
        }
    }
    public static void gradH(DrawContext c, float x, float y, float w, float h, int c1, int c2) {
        int steps = Math.max(1, (int) (w / 2));
        for (int i = 0; i < steps; i++) rect(c, x + i * w / steps, y, w / steps + 1, h, ColorUtil.lerp(c1, c2, i / (float) steps));
    }
    public static void outline(DrawContext c, float x, float y, float w, float h, int col) {
        rect(c, x, y, w, 1, col); rect(c, x, y + h - 1, w, 1, col); rect(c, x, y, 1, h, col); rect(c, x + w - 1, y, 1, h, col);
    }
    public static void text(DrawContext c, String s, float x, float y, int col, boolean shadow) {
        if (invisible(col)) return;
        c.drawText(mc.textRenderer, s, Math.round(x), Math.round(y), fade(col), shadow);
    }
    public static void textScaled(DrawContext c, String s, float x, float y, float scale, int col, boolean shadow) {
        if (invisible(col)) return;
        c.getMatrices().push(); c.getMatrices().translate(x, y, 0); c.getMatrices().scale(scale, scale, 1f);
        c.drawText(mc.textRenderer, s, 0, 0, fade(col), shadow);
        c.getMatrices().pop();
    }
    /** Per-character gradient text. */
    public static void gradText(DrawContext c, String s, float x, float y, float offset, boolean shadow) {
        float cx = x;
        for (int i = 0; i < s.length(); i++) {
            String ch = String.valueOf(s.charAt(i));
            text(c, ch, cx, y, ColorUtil.flame(offset + i * 0.35f) | 0xFF000000, shadow);
            cx += width(ch);
        }
    }
    public static int width(String s) { return mc.textRenderer.getWidth(s); }
    public static int fh() { return mc.textRenderer.fontHeight; }
    public static boolean hover(double mx, double my, float x, float y, float w, float h) { return mx >= x && mx <= x + w && my >= y && my <= y + h; }
}
