package com.flare.client.module.modules.combat;

import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.NumberSetting;

public class Reach extends Module {
    private final NumberSetting range = num("Entity Range", 3.4, 3.0, 6.0, 0.05);
    public Reach() { super("Reach", "Slightly extends your hit reach (subtle).", Category.COMBAT); }
    public double range() { return range.d(); }
    @Override public String getSuffix() { return String.valueOf(range.d()); }
}
