package com.flare.client.mixin;

import com.flare.client.FlareClient;
import com.flare.client.module.modules.render.Crosshair;
import com.flare.client.module.modules.render.NoRender;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudMixin {
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true, require = 0)
    private void flare$crosshair(CallbackInfo ci) {
        Crosshair c = FlareClient.modules == null ? null : FlareClient.modules.get(Crosshair.class);
        if (c != null && c.isEnabled()) ci.cancel();
    }
    @Inject(method = "renderNauseaOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void flare$nausea(CallbackInfo ci) {
        NoRender n = FlareClient.modules == null ? null : FlareClient.modules.get(NoRender.class);
        if (n != null && n.isEnabled() && n.nausea.is()) ci.cancel();
    }
    @Inject(method = "renderOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void flare$overlay(CallbackInfo ci) {
        NoRender n = FlareClient.modules == null ? null : FlareClient.modules.get(NoRender.class);
        if (n != null && n.isEnabled() && n.overlays.is()) ci.cancel();
    }
}
