package com.flare.client.gui;

import com.flare.client.config.ConfigManager;
import com.flare.client.util.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.List;

public class ConfigScreen extends Screen {
    private List<String> configs = ConfigManager.list();
    private String input = "", selected = "", status = "";
    private float scroll; private final Anim fade = new Anim(0, 12);

    public ConfigScreen() { super(Text.literal("Configs")); }
    @Override public boolean shouldPause() { return false; }

    private float bx() { return width / 2f - 130; }
    private static final String[] BTN = {"SAVE", "LOAD", "DELETE", "REFRESH"};

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        Draw.alpha = fade.update(1);
        ctx.fill(0, 0, width, height, Draw.fade(0xB4000000));
        ctx.fillGradient(0, height / 2, width, height, 0x00FF6B00, Draw.fade(0x38FF6B00));
        TopBar.render(ctx, mx, my, width, 2);
        float x = bx(), y = 40, w = 260, h = Math.min(height - 60, 220);
        Draw.glow(ctx, x, y, w, h, 4, ColorUtil.ORANGE, 0.5f);
        Draw.rrect(ctx, x, y, w, h, 4, 0xF00A0A0A);
        Draw.gradH(ctx, x, y + 20, w, 2, ColorUtil.ORANGE, ColorUtil.ORANGE2);
        Draw.text(ctx, "CONFIGS", x + 8, y + 7, ColorUtil.ORANGE2, true);
        // name input
        Draw.rrect(ctx, x + 8, y + 28, w - 16, 16, 3, 0xFF161616);
        Draw.outline(ctx, x + 8, y + 28, w - 16, 16, ColorUtil.alpha(ColorUtil.ORANGE, 160));
        boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
        Draw.text(ctx, input.isEmpty() ? "Config name..." : input + (blink ? "_" : ""), x + 14, y + 32, input.isEmpty() ? 0xFF666666 : 0xFFFFFFFF, false);
        // list
        float ly = y + 50, lh = h - 50 - 28; int rows = (int) (lh / 14);
        ctx.enableScissor((int) x + 8, (int) ly, (int) (x + w - 8), (int) (ly + lh));
        for (int i = 0; i < configs.size(); i++) {
            float ry = ly + i * 14 - scroll;
            boolean sel = configs.get(i).equals(selected), hov = Draw.hover(mx, my, x + 8, ry, w - 16, 13);
            Draw.rect(ctx, x + 8, ry, w - 16, 13, sel ? ColorUtil.alpha(ColorUtil.ORANGE, 170) : hov ? 0xFF1E1E1E : 0xFF101010);
            Draw.text(ctx, configs.get(i), x + 14, ry + 3, sel ? 0xFF0A0A0A : 0xFFFFFFFF, false);
        }
        ctx.disableScissor();
        // buttons
        float bw = (w - 16 - 3 * 4) / 4f;
        for (int i = 0; i < 4; i++) {
            float bx = x + 8 + i * (bw + 4), by = y + h - 22;
            boolean hov = Draw.hover(mx, my, bx, by, bw, 16);
            Draw.rrect(ctx, bx, by, bw, 16, 3, hov ? ColorUtil.ORANGE : 0xFF1C1C1C);
            Draw.text(ctx, BTN[i], bx + (bw - Draw.width(BTN[i])) / 2f, by + 4, hov ? 0xFF0A0A0A : 0xFFFFFFFF, false);
        }
        Draw.text(ctx, status, x + w / 2f - Draw.width(status) / 2f, y + h + 6, ColorUtil.ORANGE2, false);
        Draw.alpha = 1f;
    }

    private String target() { return input.isEmpty() ? selected : input; }

    @Override public boolean mouseClicked(double mx, double my, int btn) {
        Screen s = TopBar.click(mx, my, width, 2);
        if (s != null) { client.setScreen(s); return true; }
        float x = bx(), y = 40, w = 260, h = Math.min(height - 60, 220);
        float ly = y + 50;
        for (int i = 0; i < configs.size(); i++) {
            float ry = ly + i * 14 - scroll;
            if (ry >= ly - 1 && ry < y + h - 30 && Draw.hover(mx, my, x + 8, ry, w - 16, 13)) { selected = configs.get(i); input = ""; return true; }
        }
        float bw = (w - 16 - 12) / 4f;
        for (int i = 0; i < 4; i++) {
            float bx = x + 8 + i * (bw + 4), by = y + h - 22;
            if (!Draw.hover(mx, my, bx, by, bw, 16)) continue;
            String t = target();
            switch (i) {
                case 0 -> { if (t.isEmpty()) status = "Enter a name first"; else { status = ConfigManager.save(t) ? "Saved '" + t + "'" : "Save failed"; configs = ConfigManager.list(); selected = t; input = ""; } }
                case 1 -> { if (t.isEmpty()) status = "Select a config"; else status = ConfigManager.load(t) ? "Loaded '" + t + "'" : "Not found"; }
                case 2 -> { if (!t.isEmpty() && ConfigManager.delete(t)) { status = "Deleted '" + t + "'"; selected = ""; input = ""; } configs = ConfigManager.list(); }
                default -> { configs = ConfigManager.list(); status = "Refreshed"; }
            }
            return true;
        }
        return false;
    }
    @Override public boolean mouseScrolled(double mx, double my, double h, double v) { scroll = Math.max(0, Math.min(Math.max(0, configs.size() * 14 - 120), scroll - (float) v * 14)); return true; }
    @Override public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        if (key == GLFW.GLFW_KEY_BACKSPACE && !input.isEmpty()) { input = input.substring(0, input.length() - 1); return true; }
        return super.keyPressed(key, scan, mods);
    }
    @Override public boolean charTyped(char c, int mods) {
        if (input.length() < 24 && (Character.isLetterOrDigit(c) || c == '_' || c == '-')) { input += c; return true; }
        return false;
    }
}
