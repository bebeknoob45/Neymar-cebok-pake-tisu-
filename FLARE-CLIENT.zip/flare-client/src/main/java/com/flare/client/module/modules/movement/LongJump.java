package com.flare.client.module.modules.movement;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.NumberSetting;
import com.flare.client.util.MoveUtil;
import net.minecraft.util.math.Vec3d;

public class LongJump extends Module {
    private final NumberSetting boost = num("Boost", 1.8, 1.0, 4.0, 0.1);
    private final NumberSetting lift = num("Lift", 0.05, 0.0, 0.3, 0.01);
    private boolean jumped; private double cur; private int air;
    public LongJump() { super("LongJump", "Boosts your horizontal speed when you jump.", Category.MOVEMENT); }

    @Subscribe
    private void onTick(PlayerTickEvent e) {
        var p = mc.player; if (p == null) return;
        if (p.isOnGround()) {
            if (jumped && air > 2) jumped = false;
            if (MoveUtil.isMoving() && mc.options.jumpKey.isPressed()) { p.jump(); jumped = true; air = 0; cur = 0.2873 * boost.d() * 1.4; }
            return;
        }
        if (!jumped) return;
        air++; cur = Math.max(0.22, cur * 0.975);
        MoveUtil.setSpeed(cur);
        if (air < 8) { Vec3d v = p.getVelocity(); p.setVelocity(v.x, v.y + lift.d(), v.z); }
    }
}
