package com.flare.client.mixin;

import com.flare.client.FlareClient;
import com.flare.client.module.modules.render.NoRender;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true, require = 0)
    private void flare$hurt(CallbackInfo ci) {
        NoRender n = FlareClient.modules == null ? null : FlareClient.modules.get(NoRender.class);
        if (n != null && n.isEnabled() && n.hurtCam.is()) ci.cancel();
    }
}
