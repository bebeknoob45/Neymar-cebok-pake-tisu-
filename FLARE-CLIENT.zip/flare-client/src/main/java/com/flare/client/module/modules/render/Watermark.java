package com.flare.client.module.modules.render;

import com.flare.client.FlareClient;
import com.flare.client.module.HudModule;
import com.flare.client.setting.BoolSetting;
import com.flare.client.util.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

public class Watermark extends HudModule {
    private final BoolSetting info = bool("Show FPS / Ping", true);
    public Watermark() { super("Watermark", "FLARE CLIENT watermark.", 6, 6); }

    @Override
    public void drawHud(DrawContext ctx, boolean editing) {
        String extra = "";
        if (info.is()) {
            int ping = 0; if (mc.getNetworkHandler() != null && mc.player != null) { PlayerListEntry pe = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()); if (pe != null) ping = pe.getLatency(); }
            extra = "  " + mc.getCurrentFps() + " FPS  " + ping + " ms";
        }
        float tw = Draw.width("FLARE CLIENT") * 1.2f + Draw.width(extra) + 12;
        Draw.glow(ctx, x, y, tw, 15, 3, ColorUtil.ORANGE, 0.55f);
        Draw.rrect(ctx, x, y, tw, 15, 3, 0xE60A0A0A);
        Draw.gradH(ctx, x + 2, y + 13, tw - 4, 1.5f, ColorUtil.ORANGE, ColorUtil.ORANGE2);
        ctx.getMatrices().push(); ctx.getMatrices().translate(x + 5, y + 3, 0); ctx.getMatrices().scale(1.2f, 1.2f, 1f);
        Draw.gradText(ctx, "FLARE CLIENT", 0, 0, 0, true);
        ctx.getMatrices().pop();
        Draw.text(ctx, extra, x + 5 + Draw.width("FLARE CLIENT") * 1.2f, y + 4, 0xFFB0B0B0, false);
        w = tw; h = 15;
    }
}
