package com.flare.client.mixin;

import com.flare.client.FlareClient;
import com.flare.client.module.modules.render.Nametags;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntityRenderer.class)
public class LivingEntityRendererMixin {
    @Inject(method = "hasLabel", at = @At("HEAD"), cancellable = true, require = 0)
    private void flare$label(CallbackInfoReturnable<Boolean> cir) {
        Nametags n = FlareClient.modules == null ? null : FlareClient.modules.get(Nametags.class);
        if (n != null && n.isEnabled()) cir.setReturnValue(false);
    }
}
