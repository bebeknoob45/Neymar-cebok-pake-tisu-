package com.flare.client.module.modules.player;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.PacketEvent;
import com.flare.client.event.events.TickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import com.flare.client.util.PacketUtil;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import java.util.ArrayDeque;
import java.util.Queue;

public class Blink extends Module {
    private final NumberSetting maxSeconds = num("Max Seconds", 10, 1, 30, 1);
    private final BoolSetting allPackets = bool("All Packets", false);
    private final Queue<Packet<?>> queue = new ArrayDeque<>(); private int ticks;
    public Blink() { super("Blink", "Holds your movement packets, then releases them at once.", Category.PLAYER); }
    @Override protected void onEnable() { ticks = 0; }
    @Override protected void onDisable() { flush(); }
    @Override public String getSuffix() { return String.valueOf(queue.size()); }

    @Subscribe
    private void onSend(PacketEvent.Send e) {
        if (e.packet instanceof PlayerMoveC2SPacket || allPackets.is()) { queue.add(e.packet); e.cancel(); }
    }
    @Subscribe
    private void onTick(TickEvent.Post e) { if (++ticks > maxSeconds.i() * 20) setEnabled(false); }
    private void flush() { while (!queue.isEmpty()) PacketUtil.sendSilent(queue.poll()); }
}
