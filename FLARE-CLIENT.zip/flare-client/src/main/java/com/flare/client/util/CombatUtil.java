package com.flare.client.util;

import com.flare.client.FriendManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.Difficulty;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.RaycastContext;

public final class CombatUtil {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public static boolean isFriend(Entity e) { return e instanceof PlayerEntity p && FriendManager.isFriend(p.getName().getString()); }

    public static double distanceToBox(Vec3d p, Box b) {
        double dx = Math.max(Math.max(b.minX - p.x, 0), p.x - b.maxX), dy = Math.max(Math.max(b.minY - p.y, 0), p.y - b.maxY), dz = Math.max(Math.max(b.minZ - p.z, 0), p.z - b.maxZ);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    public static boolean rayClear(Vec3d from, Vec3d to) {
        return mc.world.raycast(new RaycastContext(from, to, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player)).getType() == HitResult.Type.MISS;
    }
    public static boolean canSee(Entity e) {
        Vec3d eye = mc.player.getEyePos(); Box b = e.getBoundingBox();
        return rayClear(eye, b.getCenter()) || rayClear(eye, new Vec3d(b.getCenter().x, b.maxY - 0.1, b.getCenter().z)) || rayClear(eye, new Vec3d(b.getCenter().x, b.minY + 0.1, b.getCenter().z));
    }
    public static Vec3d aimPoint(Entity e) {
        Vec3d eye = mc.player.getEyePos(); Box b = e.getBoundingBox();
        Vec3d p = new Vec3d(MathHelper.clamp(eye.x, b.minX + 0.1, b.maxX - 0.1), MathHelper.clamp(eye.y, b.minY + 0.2, b.maxY - 0.1), MathHelper.clamp(eye.z, b.minZ + 0.1, b.maxZ - 0.1));
        return p.distanceTo(eye) < 0.2 ? b.getCenter() : p;
    }
    public static boolean lookingAt(float yaw, float pitch, Entity e, double range) {
        Vec3d eye = mc.player.getEyePos(), look = Vec3d.fromPolar(pitch, yaw);
        return e.getBoundingBox().expand(0.08).raycast(eye, eye.add(look.multiply(range))).isPresent();
    }
    public static boolean validLiving(Entity e) {
        return e instanceof LivingEntity l && e != mc.player && !(e instanceof ArmorStandEntity) && l.isAlive() && l.getHealth() > 0 && !e.isSpectator();
    }
    public static PlayerEntity nearestPlayer(double range) {
        PlayerEntity best = null; double bd = range;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !p.isAlive() || p.isSpectator() || isFriend(p)) continue;
            double d = mc.player.distanceTo(p);
            if (d < bd) { bd = d; best = p; }
        }
        return best;
    }

    public static double exposure(Vec3d pos, LivingEntity e) {
        Box b = e.getBoundingBox(); Vec3d c = b.getCenter(); int vis = 0;
        Vec3d[] pts = {c, new Vec3d(c.x, b.minY + 0.1, c.z), new Vec3d(c.x, b.maxY - 0.1, c.z), new Vec3d(b.minX + 0.1, c.y, c.z), new Vec3d(b.maxX - 0.1, c.y, c.z)};
        for (Vec3d p : pts)
            if (mc.world.raycast(new RaycastContext(pos, p, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, e)).getType() == HitResult.Type.MISS) vis++;
        return vis / 5.0;
    }
    /** Approximation of end crystal explosion damage (power 6). */
    public static float crystalDamage(Vec3d pos, LivingEntity e) {
        double dist = Math.sqrt(e.squaredDistanceTo(pos)) / 12.0;
        if (dist > 1) return 0;
        double impact = (1 - dist) * exposure(pos, e);
        float dmg = (float) ((impact * impact + impact) / 2 * 7 * 12 + 1);
        Difficulty d = mc.world.getDifficulty();
        dmg = d == Difficulty.PEACEFUL ? 0 : d == Difficulty.EASY ? Math.min(dmg / 2f + 1f, dmg) : d == Difficulty.HARD ? dmg * 1.5f : dmg;
        dmg *= 1f - Math.min(20f, e.getArmor()) / 25f;
        return Math.max(0, dmg - e.getAbsorptionAmount());
    }
}
