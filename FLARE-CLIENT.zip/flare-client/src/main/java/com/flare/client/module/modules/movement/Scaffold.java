package com.flare.client.module.modules.movement;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import com.flare.client.util.*;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.FallingBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class Scaffold extends Module {
    private final NumberSetting delay = num("Delay", 0, 0, 5, 1);
    private final NumberSetting expand = num("Expand", 0, 0, 4, 1);
    private final ModeSetting rotate = mode("Rotate", "Snap", "None", "Snap");
    private final BoolSetting tower = bool("Tower", true), eagle = bool("Eagle", false), swing = bool("Swing", true);
    private int tick; private boolean eagled;
    public Scaffold() { super("Scaffold", "Places blocks under your feet as you move.", Category.MOVEMENT); }

    @Override protected void onDisable() { if (eagled) { mc.options.sneakKey.setPressed(false); eagled = false; } }

    private int findSlot() {
        int best = -1, count = 0;
        for (int i = 0; i < 9; i++) {
            var s = mc.player.getInventory().getStack(i);
            if (s.getItem() instanceof BlockItem bi && !(bi.getBlock() instanceof FallingBlock) && !(bi.getBlock() instanceof BlockWithEntity) && s.getCount() > count) { best = i; count = s.getCount(); }
        }
        return best;
    }

    @Subscribe
    private void onTick(PlayerTickEvent e) {
        var p = mc.player; if (p == null) return;
        int slot = findSlot(); if (slot < 0) return;
        BlockPos below = p.getBlockPos().down();
        if (eagle.is()) { boolean edge = mc.world.getBlockState(below).isReplaceable() && p.isOnGround(); mc.options.sneakKey.setPressed(edge || (eagled && false)); eagled = edge; }
        if (tower.is() && mc.options.jumpKey.isPressed() && !MoveUtil.isMoving() && mc.world.getBlockState(below).isReplaceable() == false && p.getVelocity().y < 0.1 && p.isOnGround()) p.jump();
        if (++tick <= delay.i()) return;
        BlockPos target = below;
        if (expand.i() > 0 && MoveUtil.isMoving()) {
            double[] d = MoveUtil.dir(p.getYaw());
            for (int i = expand.i(); i >= 0; i--) { BlockPos c = BlockPos.ofFloored(p.getX() + d[0] * i, p.getY() - 1, p.getZ() + d[1] * i); if (mc.world.getBlockState(c).isReplaceable()) { target = c; break; } }
        }
        if (!mc.world.getBlockState(target).isReplaceable()) return;
        if (BlockUtil.place(target, slot, rotate.is("Snap"), swing.is())) {
            tick = 0;
            if (tower.is() && mc.options.jumpKey.isPressed() && !MoveUtil.isMoving()) { Vec3d v = p.getVelocity(); p.setVelocity(v.x, 0.42, v.z); }
        }
    }
}
