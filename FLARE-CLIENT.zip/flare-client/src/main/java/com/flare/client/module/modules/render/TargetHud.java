package com.flare.client.module.modules.render;

import com.flare.client.FlareClient;
import com.flare.client.module.HudModule;
import com.flare.client.module.modules.combat.AutoCrystal;
import com.flare.client.module.modules.combat.KillAura;
import com.flare.client.util.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

public class TargetHud extends HudModule {
    private final Anim hpAnim = new Anim(1, 10), show = new Anim(0, 12);
    private LivingEntity last;
    public TargetHud() { super("TargetHUD", "Shows health and info of your current target.", 260, 200); }

    private LivingEntity find() {
        KillAura ka = FlareClient.modules.get(KillAura.class); AutoCrystal ac = FlareClient.modules.get(AutoCrystal.class);
        if (ka != null && ka.isEnabled() && ka.getTarget() != null) return ka.getTarget();
        if (ac != null && ac.isEnabled() && ac.getTarget() != null) return ac.getTarget();
        Entity t = mc.targetedEntity;
        return t instanceof PlayerEntity p ? p : null;
    }

    @Override
    public void drawHud(DrawContext ctx, boolean editing) {
        LivingEntity t = find();
        if (t != null) last = t;
        float a = show.update(t != null || editing ? 1 : 0);
        w = 130; h = 38;
        if (a < 0.02f) return;
        String name = "Preview"; float hp = 14, max = 20, dist = 3.2f, armor = 12;
        if (last != null && !editing || last != null && t != null) { name = last.getName().getString(); hp = last.getHealth() + last.getAbsorptionAmount(); max = last.getMaxHealth(); dist = mc.player.distanceTo(last); armor = last.getArmor(); }
        Draw.alpha = a;
        Draw.glow(ctx, x, y, w, h, 3, ColorUtil.ORANGE, 0.6f);
        Draw.rrect(ctx, x, y, w, h, 3, 0xEB0A0A0A);
        Draw.rect(ctx, x, y + 3, 2, h - 6, ColorUtil.ORANGE);
        Draw.text(ctx, name, x + 8, y + 5, 0xFFFFFFFF, true);
        String info = String.format("%.1f HP", hp);
        Draw.text(ctx, info, x + w - 6 - Draw.width(info), y + 5, hp / max > 0.5f ? 0xFF55FF55 : hp / max > 0.25f ? 0xFFFFAA00 : 0xFFFF5555, false);
        float frac = hpAnim.update(Math.max(0, Math.min(1, hp / max)));
        Draw.rrect(ctx, x + 8, y + 18, w - 16, 6, 2, 0xFF1E1E1E);
        Draw.gradH(ctx, x + 8, y + 18, (w - 16) * frac, 6, ColorUtil.ORANGE, ColorUtil.ORANGE2);
        Draw.text(ctx, String.format("%.1fm", dist) + "   Armor " + (int) armor, x + 8, y + 27, 0xFFB0B0B0, false);
        Draw.alpha = 1f;
    }
}
