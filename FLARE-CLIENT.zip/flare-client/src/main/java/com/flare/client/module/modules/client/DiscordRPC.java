package com.flare.client.module.modules.client;

import com.flare.client.FlareClient;
import com.flare.client.event.Subscribe;
import com.flare.client.event.events.TickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import net.fabricmc.loader.api.FabricLoader;
import java.io.*;
import java.net.StandardProtocolFamily;
import java.net.UnixDomainSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.UUID;

/**
 * Dependency-free Discord Rich Presence (raw IPC). Put your Discord application ID in
 * .minecraft/flare/discord_client_id.txt (create an app at discord.com/developers).
 */
public class DiscordRPC extends Module {
    private InputStream in; private OutputStream out; private Closeable conn;
    private long startSec; private int ticks; private volatile boolean connecting;

    public DiscordRPC() { super("DiscordRPC", "Shows FLARE CLIENT in your Discord status.", Category.CLIENT); }

    private String clientId() {
        Path p = FabricLoader.getInstance().getGameDir().resolve("flare/discord_client_id.txt");
        try {
            if (!Files.exists(p)) { Files.createDirectories(p.getParent()); Files.writeString(p, "1000000000000000000"); }
            return Files.readString(p).trim();
        } catch (Exception e) { return "1000000000000000000"; }
    }

    @Override protected void onEnable() {
        startSec = System.currentTimeMillis() / 1000; ticks = 0;
        if (connecting) return;
        connecting = true;
        Thread t = new Thread(() -> { try { connect(); update(); } catch (Throwable ignored) { close(); } finally { connecting = false; } }, "Flare-RPC");
        t.setDaemon(true); t.start();
    }
    @Override protected void onDisable() { close(); }

    @Subscribe
    private void onTick(TickEvent.Post e) {
        if (out == null || ++ticks % 300 != 0) return;
        Thread t = new Thread(() -> { try { update(); } catch (Throwable ex) { close(); } }, "Flare-RPC-update");
        t.setDaemon(true); t.start();
    }

    private void connect() throws Exception {
        boolean win = System.getProperty("os.name").toLowerCase().contains("win");
        for (int i = 0; i < 10 && out == null; i++) {
            try {
                if (win) {
                    RandomAccessFile raf = new RandomAccessFile("\\\\?\\pipe\\discord-ipc-" + i, "rw");
                    in = Channels.newInputStream(raf.getChannel()); out = Channels.newOutputStream(raf.getChannel()); conn = raf;
                } else {
                    String[] dirs = {System.getenv("XDG_RUNTIME_DIR"), System.getenv("TMPDIR"), System.getenv("TMP"), System.getenv("TEMP"), "/tmp"};
                    for (String d : dirs) {
                        if (d == null) continue;
                        Path p = Path.of(d, "discord-ipc-" + i);
                        if (!Files.exists(p)) continue;
                        SocketChannel ch = SocketChannel.open(StandardProtocolFamily.UNIX);
                        ch.connect(UnixDomainSocketAddress.of(p));
                        in = Channels.newInputStream(ch); out = Channels.newOutputStream(ch); conn = ch; break;
                    }
                }
            } catch (Throwable ignored) { in = null; out = null; }
        }
        if (out == null) throw new IOException("Discord not found");
        send(0, "{\"v\":1,\"client_id\":\"" + clientId() + "\"}");
        readFrame();
    }

    private void update() throws Exception {
        if (out == null) return;
        String state = mc.world == null ? "In menus" : (mc.getCurrentServerEntry() != null ? "Playing " + mc.getCurrentServerEntry().address : "Singleplayer");
        String json = "{\"cmd\":\"SET_ACTIVITY\",\"args\":{\"pid\":" + ProcessHandle.current().pid() + ",\"activity\":{\"details\":\"" + FlareClient.NAME + " " + FlareClient.VERSION
                + "\",\"state\":\"" + state.replace("\"", "'") + "\",\"timestamps\":{\"start\":" + startSec + "}}},\"nonce\":\"" + UUID.randomUUID() + "\"}";
        send(1, json);
        readFrame();
    }

    private synchronized void send(int op, String json) throws IOException {
        byte[] d = json.getBytes(StandardCharsets.UTF_8);
        ByteBuffer b = ByteBuffer.allocate(8 + d.length).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(op).putInt(d.length).put(d);
        out.write(b.array()); out.flush();
    }
    private void readFrame() throws IOException {
        byte[] h = in.readNBytes(8);
        if (h.length < 8) throw new IOException("closed");
        int len = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN).getInt(4);
        if (len > 0 && len < 65536) in.readNBytes(len);
    }
    private void close() { try { if (conn != null) conn.close(); } catch (Exception ignored) {} conn = null; in = null; out = null; }
}
