package com.flare.client.gui;

import com.flare.client.FlareClient;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.util.*;
import net.minecraft.client.gui.DrawContext;
import java.util.ArrayList;
import java.util.List;

public class Panel {
    public static final float HEADER = 20;
    public final Category cat; public float x, y, w = 112; public boolean open = true;
    private final Anim openAnim = new Anim(1, 14);
    public final List<ModuleButton> buttons = new ArrayList<>();
    private boolean dragging, moved; private float dx, dy, startX, startY;
    public float lastHeight;

    public Panel(Category c, float x, float y) {
        cat = c; this.x = x; this.y = y;
        for (Module m : FlareClient.modules.inCategory(c)) buttons.add(new ModuleButton(m));
    }

    public void render(DrawContext ctx, int mx, int my, float scroll, String filter, float slide) {
        List<ModuleButton> list = new ArrayList<>();
        for (ModuleButton b : buttons) if (b.matches(filter)) list.add(b);
        if (!filter.isEmpty() && list.isEmpty()) { lastHeight = 0; return; }
        float py = y + scroll + slide;
        // header
        Draw.glow(ctx, x, py, w, HEADER, 3, ColorUtil.ORANGE, 0.5f);
        Draw.rrect(ctx, x, py, w, HEADER, 3, 0xFF0A0A0A);
        Draw.gradH(ctx, x, py + HEADER - 2, w, 2, ColorUtil.ORANGE, ColorUtil.ORANGE2);
        Draw.text(ctx, cat.label.toUpperCase(), x + 7, py + 6, ColorUtil.flame(cat.ordinal()) | 0xFF000000, true);
        Draw.text(ctx, open ? "-" : "+", x + w - 11, py + 6, 0xFF888888, false);
        // body
        float total = 0;
        for (ModuleButton b : list) total += ModuleButton.H + 0; // measured below
        float oa = openAnim.update(open || !filter.isEmpty() ? 1 : 0);
        float cy = py + HEADER, used = 0;
        // compute actual height by rendering inside scissor with clipping proportional to anim
        float clipH = lastHeight * oa;
        if (oa > 0.01f) {
            ctx.enableScissor(Math.round(x), Math.round(cy), Math.round(x + w), Math.round(cy + Math.max(clipH, 1)));
            for (ModuleButton b : list) { float h = b.render(ctx, mx, my, x, cy + used, w); used += h; }
            ctx.disableScissor();
            lastHeight = used;
            if (oa > 0.99f) Draw.rect(ctx, x, cy + used, w, 1, ColorUtil.alpha(ColorUtil.ORANGE, 160));
        } else { lastHeight = Math.max(lastHeight, list.size() * ModuleButton.H); }
    }

    public float bottom(float scroll) { return y + scroll + HEADER + lastHeight * openAnim.get(); }
    public boolean overHeader(double mx, double my, float scroll) { return Draw.hover(mx, my, x, y + scroll, w, HEADER); }
    public boolean overAny(double mx, double my, float scroll) { return Draw.hover(mx, my, x, y + scroll, w, HEADER + lastHeight * openAnim.get() + 2); }

    public boolean click(double mx, double my, int btn, float scroll) {
        if (overHeader(mx, my, scroll)) {
            if (btn == 0) { dragging = true; moved = false; dx = (float) mx - x; dy = (float) my - y; startX = (float) mx; startY = (float) my; }
            else if (btn == 1) open = !open;
            return true;
        }
        if (open) for (ModuleButton b : buttons) if (b.click(mx, my, btn)) return true;
        return overAny(mx, my, scroll);
    }
    public void drag(double mx, double my) {
        if (dragging) { if (Math.abs(mx - startX) + Math.abs(my - startY) > 3) moved = true; if (moved) { x = (float) mx - dx; y = (float) my - dy; } }
        for (ModuleButton b : buttons) b.drag(mx);
    }
    public void release() { if (dragging && !moved) open = !open; dragging = false; for (ModuleButton b : buttons) b.release(); }
    public boolean key(int k) { for (ModuleButton b : buttons) if (b.key(k)) return true; return false; }
    public boolean listening() { for (ModuleButton b : buttons) if (b.isListening()) return true; return false; }
}
