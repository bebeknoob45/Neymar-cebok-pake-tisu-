package com.flare.client.module.modules.combat;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.PacketEvent;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.util.math.Vec3d;

public class Velocity extends Module {
    private final ModeSetting mode = mode("Mode", "Reduce", "Cancel", "Reduce");
    private final NumberSetting horizontal = (NumberSetting) num("Horizontal %", 30, 0, 100, 1).visibleIf(() -> mode.is("Reduce"));
    private final NumberSetting vertical = (NumberSetting) num("Vertical %", 100, 0, 100, 1).visibleIf(() -> mode.is("Reduce"));
    private volatile boolean pending;
    public Velocity() { super("Velocity", "Reduces or cancels knockback.", Category.COMBAT); }

    @Subscribe
    private void onPacket(PacketEvent.Receive e) {
        if (mc.player == null) return;
        if (e.packet instanceof EntityVelocityUpdateS2CPacket p && p.getEntityId() == mc.player.getId()) pending = true;
        else if (e.packet instanceof ExplosionS2CPacket) pending = true;
    }

    @Subscribe
    private void onTick(PlayerTickEvent e) {
        if (!pending) return;
        pending = false;
        double h = mode.is("Cancel") ? 0 : horizontal.d() / 100.0, v = mode.is("Cancel") ? 0 : vertical.d() / 100.0;
        Vec3d vel = mc.player.getVelocity();
        mc.player.setVelocity(vel.x * h, vel.y * v, vel.z * h);
    }
}
