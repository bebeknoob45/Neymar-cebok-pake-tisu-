package com.flare.client.gui;

import com.flare.client.FlareClient;
import com.flare.client.module.modules.client.ClickGuiModule;
import com.flare.client.util.*;
import net.minecraft.client.gui.DrawContext;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Orange toast-style notifications (bottom-right). */
public final class NotificationManager {
    private static final class Note { String title, msg; boolean good; long born = System.currentTimeMillis(); Anim slide = new Anim(0, 12); }
    private static final List<Note> notes = new ArrayList<>();

    public static void push(String title, String msg, boolean good) {
        ClickGuiModule g = FlareClient.modules == null ? null : FlareClient.modules.get(ClickGuiModule.class);
        if (g != null && !g.notifications.is()) return;
        Note n = new Note(); n.title = title; n.msg = msg; n.good = good;
        notes.add(n);
        if (notes.size() > 6) notes.remove(0);
    }

    public static void render(DrawContext ctx) {
        Draw.alpha = 1f;
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        float y = sh - 8;
        for (Iterator<Note> it = notes.iterator(); it.hasNext(); ) {
            Note n = it.next();
            long age = System.currentTimeMillis() - n.born;
            float t = n.slide.update(age < 2300 ? 1f : 0f);
            if (age > 2300 && t <= 0.01f) { it.remove(); continue; }
            float w = Math.max(100, Draw.width(n.title + "  " + n.msg) + 22), h = 24;
            float x = sw - (w + 8) * t;
            y -= h + 4;
            int accent = n.good ? ColorUtil.ORANGE : 0xFF6A6A6A;
            Draw.glow(ctx, x, y, w, h, 3, accent, 0.6f * t);
            Draw.rrect(ctx, x, y, w, h, 3, 0xF00A0A0A);
            Draw.rect(ctx, x, y + 3, 2, h - 6, accent);
            Draw.text(ctx, n.title, x + 8, y + 4, 0xFFFFFFFF, true);
            Draw.text(ctx, n.msg, x + 8, y + 14, n.good ? ColorUtil.ORANGE2 : 0xFFAAAAAA, false);
            float prog = 1f - Math.min(1f, age / 2300f);
            Draw.rect(ctx, x + 2, y + h - 2, (w - 4) * prog, 1.5f, accent);
        }
    }
}
