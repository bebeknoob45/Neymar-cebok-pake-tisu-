package com.flare.client;

import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;
import java.util.*;

public final class FriendManager {
    private static final Set<String> friends = new HashSet<>();
    private static final Path FILE = FabricLoader.getInstance().getGameDir().resolve("flare/friends.txt");
    public static boolean isFriend(String n) { return friends.contains(n.toLowerCase()); }
    public static void toggle(String n) { n = n.toLowerCase(); if (!friends.remove(n)) friends.add(n); save(); }
    public static void load() {
        try { if (Files.exists(FILE)) friends.addAll(Files.readAllLines(FILE)); } catch (Exception ignored) {}
    }
    private static void save() {
        try { Files.createDirectories(FILE.getParent()); Files.write(FILE, friends); } catch (Exception ignored) {}
    }
}
