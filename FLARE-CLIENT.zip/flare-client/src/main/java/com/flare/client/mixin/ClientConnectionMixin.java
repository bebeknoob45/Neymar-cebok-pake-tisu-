package com.flare.client.mixin;

import com.flare.client.FlareClient;
import com.flare.client.event.events.PacketEvent;
import com.flare.client.util.PacketUtil;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientConnection.class)
public class ClientConnectionMixin {
    @Inject(method = "send(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/PacketCallbacks;Z)V", at = @At("HEAD"), cancellable = true)
    private void flare$send(Packet<?> packet, net.minecraft.network.PacketCallbacks cb, boolean flush, CallbackInfo ci) {
        if (PacketUtil.silent || FlareClient.EVENT_BUS == null) return;
        if (FlareClient.EVENT_BUS.post(new PacketEvent.Send(packet)).isCancelled()) ci.cancel();
    }

    @Inject(method = "handlePacket", at = @At("HEAD"), cancellable = true, require = 0)
    private static void flare$receive(Packet<?> packet, PacketListener listener, CallbackInfo ci) {
        if (!(listener instanceof ClientPlayPacketListener)) return;
        if (FlareClient.EVENT_BUS.post(new PacketEvent.Receive(packet)).isCancelled()) ci.cancel();
    }
}
