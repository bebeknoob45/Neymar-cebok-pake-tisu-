package com.flare.client.module.modules.client;

import com.flare.client.gui.ClickGuiScreen;
import com.flare.client.gui.Panel;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.BoolSetting;
import com.google.gson.JsonObject;
import org.lwjgl.glfw.GLFW;

public class ClickGuiModule extends Module {
    /** True while the screen itself is closing, so onDisable must not call setScreen again (nested setScreen crashed the game). */
    public static boolean suppress;
    public final BoolSetting notifications = bool("Notifications", true);
    public final BoolSetting particles = bool("Particles", true);

    public ClickGuiModule() {
        super("ClickGUI", "Opens the FLARE menu. Default key: Right Shift.", Category.CLIENT);
        bind.set(GLFW.GLFW_KEY_RIGHT_SHIFT);
    }
    @Override protected void onEnable() { mc.setScreen(new ClickGuiScreen()); }
    @Override protected void onDisable() { if (!suppress && mc.currentScreen instanceof ClickGuiScreen) mc.setScreen(null); }

    @Override public void onSave(JsonObject o) {
        for (Panel p : ClickGuiScreen.PANELS) {
            JsonObject j = new JsonObject(); j.addProperty("x", p.x); j.addProperty("y", p.y); j.addProperty("open", p.open);
            o.add(p.cat.name(), j);
        }
    }
    @Override public void onLoad(JsonObject o) {
        // panel layout is applied lazily when the GUI opens first
        ClickGuiScreen.PANELS.clear();
        float x = 10;
        for (com.flare.client.module.Category c : com.flare.client.module.Category.values()) {
            Panel p = new Panel(c, x, 38);
            if (o.has(c.name())) { JsonObject j = o.getAsJsonObject(c.name()); p.x = j.get("x").getAsFloat(); p.y = j.get("y").getAsFloat(); p.open = j.get("open").getAsBoolean(); }
            ClickGuiScreen.PANELS.add(p); x += 120;
        }
    }
}
