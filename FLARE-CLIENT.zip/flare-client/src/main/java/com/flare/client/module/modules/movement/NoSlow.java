package com.flare.client.module.modules.movement;

import com.flare.client.module.Category;
import com.flare.client.module.Module;

/** The slowdown itself is removed in ClientPlayerEntityMixin while this module is enabled. */
public class NoSlow extends Module {
    public NoSlow() { super("NoSlow", "No slowdown while eating, drinking or using a bow.", Category.MOVEMENT); }
}
