package com.flare.client.module.modules.render;

import com.flare.client.FlareClient;
import com.flare.client.module.HudModule;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import com.flare.client.util.*;
import net.minecraft.client.gui.DrawContext;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ArrayListHud extends HudModule {
    private final BoolSetting background = bool("Background", true), bar = bool("Side Bar", true), hideRender = bool("Hide Render Modules", false);
    private final ModeSetting colorMode = mode("Colors", "Flame", "Flame", "Rainbow");
    public ArrayListHud() { super("ArrayList", "List of enabled modules (orange/black).", -1, 4); }

    @Override public float left() { return x - w; }
    @Override public void setLeft(float l) { x = l + w; }

    @Override
    public void drawHud(DrawContext ctx, boolean editing) {
        if (x < 0) x = ctx.getScaledWindowWidth() - 3;
        List<Module> list = new ArrayList<>();
        for (Module m : FlareClient.modules.all()) {
            float a = m.listAnim.update(m.isEnabled() && !(hideRender.is() && m.getCategory() == com.flare.client.module.Category.RENDER) ? 1 : 0);
            if (a > 0.01f) list.add(m);
        }
        list.sort(Comparator.comparingInt((Module m) -> -Draw.width(label(m))));
        float cy = y, maxW = 40; int i = 0;
        for (Module m : list) {
            float a = m.listAnim.get(); String name = m.getName(), suf = m.getSuffix();
            float tw = Draw.width(label(m)), ew = tw + 7, ex = x - ew * a;
            int col = colorMode.is("Rainbow") ? ColorUtil.rainbow(1f, i * 0.05f, 255) : ColorUtil.flame(i * 0.45f) | 0xFF000000;
            if (background.is()) Draw.rect(ctx, ex - 2, cy, ew + 2, 11, 0xA00A0A0A);
            if (bar.is()) Draw.rect(ctx, x - 2 * a, cy, 2, 11, col);
            Draw.text(ctx, name, ex + 1, cy + 1.5f, col, true);
            if (!suf.isEmpty()) Draw.text(ctx, suf, ex + 1 + Draw.width(name + " "), cy + 1.5f, 0xFFB0B0B0, true);
            cy += 11 * a; i++; maxW = Math.max(maxW, ew + 2);
        }
        w = maxW; h = Math.max(11, cy - y);
        if (editing && list.isEmpty()) { Draw.text(ctx, "ArrayList", x - 40, y + 1, 0xFFFF6B00, true); w = 44; h = 11; }
    }
    private String label(Module m) { return m.getSuffix().isEmpty() ? m.getName() : m.getName() + " " + m.getSuffix(); }
}
