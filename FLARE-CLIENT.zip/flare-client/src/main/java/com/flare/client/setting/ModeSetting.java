package com.flare.client.setting;
import com.google.gson.*;
import java.util.Arrays;
public class ModeSetting extends Setting<String> {
    public final String[] modes;
    public ModeSetting(String n, String d, String... modes) { super(n, d); this.modes = modes; }
    public boolean is(String s) { return value.equalsIgnoreCase(s); }
    public int index() { return Math.max(0, Arrays.asList(modes).indexOf(value)); }
    public void cycle(boolean fwd) { int i = index() + (fwd ? 1 : -1); value = modes[(i + modes.length) % modes.length]; }
    public JsonElement save() { return new JsonPrimitive(value); }
    public void load(JsonElement e) { if (Arrays.asList(modes).contains(e.getAsString())) value = e.getAsString(); }
}
