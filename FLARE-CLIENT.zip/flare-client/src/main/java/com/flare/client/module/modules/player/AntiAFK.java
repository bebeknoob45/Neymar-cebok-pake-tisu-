package com.flare.client.module.modules.player;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import net.minecraft.util.Hand;
import java.util.Random;

public class AntiAFK extends Module {
    private final NumberSetting interval = num("Interval (s)", 15, 3, 60, 1);
    private final BoolSetting jump = bool("Jump", true), swing = bool("Swing", true), look = bool("Look Around", true), walk = bool("Walk", false);
    private int ticks, walkTicks; private final Random r = new Random();
    public AntiAFK() { super("AntiAFK", "Performs small actions so you do not get kicked.", Category.PLAYER); }
    @Override protected void onDisable() { mc.options.forwardKey.setPressed(false); }

    @Subscribe
    private void onTick(PlayerTickEvent e) {
        if (mc.player == null) return;
        if (walkTicks > 0 && --walkTicks == 0) mc.options.forwardKey.setPressed(false);
        if (++ticks < interval.i() * 20) return; ticks = 0;
        if (jump.is() && mc.player.isOnGround()) mc.player.jump();
        if (swing.is()) mc.player.swingHand(Hand.MAIN_HAND);
        if (look.is()) { mc.player.setYaw(mc.player.getYaw() + (r.nextFloat() - 0.5f) * 40f); mc.player.setPitch(Math.max(-60, Math.min(60, mc.player.getPitch() + (r.nextFloat() - 0.5f) * 10f))); }
        if (walk.is()) { mc.options.forwardKey.setPressed(true); walkTicks = 10; }
    }
}
