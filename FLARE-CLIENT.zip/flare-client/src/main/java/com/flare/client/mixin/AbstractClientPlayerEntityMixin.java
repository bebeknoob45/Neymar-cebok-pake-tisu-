package com.flare.client.mixin;

import com.flare.client.IdentityManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractClientPlayerEntity.class)
public class AbstractClientPlayerEntityMixin {
    @SuppressWarnings({"rawtypes", "unchecked"})
    @Inject(method = "getSkinTextures", at = @At("RETURN"), cancellable = true, require = 0)
    private void flare$skin(CallbackInfoReturnable cir) {
        if ((Object) this != MinecraftClient.getInstance().player) return;
        Object o = IdentityManager.overrideSkin(cir.getReturnValue());
        if (o != null) cir.setReturnValue(o);
    }
}
