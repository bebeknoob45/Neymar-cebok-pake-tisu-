package com.flare.client.util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;
public final class MoveUtil {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public static boolean isMoving() {
        return mc.options.forwardKey.isPressed() || mc.options.backKey.isPressed() || mc.options.leftKey.isPressed() || mc.options.rightKey.isPressed();
    }
    public static double[] dir(float yaw) {
        float f = (mc.options.forwardKey.isPressed() ? 1 : 0) - (mc.options.backKey.isPressed() ? 1 : 0);
        float s = (mc.options.leftKey.isPressed() ? 1 : 0) - (mc.options.rightKey.isPressed() ? 1 : 0);
        if (f == 0 && s == 0) return new double[]{0, 0};
        double r = Math.toRadians(yaw), sin = Math.sin(r), cos = Math.cos(r);
        double x = -sin * f + cos * s, z = cos * f + sin * s, l = Math.sqrt(x * x + z * z);
        return new double[]{x / l, z / l};
    }
    public static void setSpeed(double speed) {
        double[] d = dir(mc.player.getYaw());
        mc.player.setVelocity(d[0] * speed, mc.player.getVelocity().y, d[1] * speed);
    }
    public static double speed() { Vec3d v = mc.player.getVelocity(); return Math.hypot(v.x, v.z); }
}
