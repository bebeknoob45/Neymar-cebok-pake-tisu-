package com.flare.client.module;

import com.flare.client.FlareClient;
import com.flare.client.gui.NotificationManager;
import com.flare.client.setting.*;
import com.flare.client.util.Anim;
import com.google.gson.JsonObject;
import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();
    private final String name, description; private final Category category;
    private boolean enabled;
    public final KeybindSetting bind = new KeybindSetting("Keybind", -1);
    protected final List<Setting<?>> settings = new ArrayList<>();
    public final Anim listAnim = new Anim(0, 14);

    public Module(String name, String description, Category category) { this.name = name; this.description = description; this.category = category; }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public boolean isEnabled() { return enabled; }
    public List<Setting<?>> getSettings() { return settings; }

    public void toggle() { setEnabled(!enabled); }
    public void setEnabled(boolean v) { setEnabled(v, true); }
    public void setEnabled(boolean v, boolean notify) {
        if (v == enabled) return;
        enabled = v;
        if (v) { FlareClient.EVENT_BUS.register(this); try { onEnable(); } catch (Throwable t) { FlareClient.LOG.error("onEnable " + name, t); } }
        else { FlareClient.EVENT_BUS.unregister(this); try { onDisable(); } catch (Throwable t) { FlareClient.LOG.error("onDisable " + name, t); } }
        if (notify && mc.player != null) NotificationManager.push(name, v ? "Enabled" : "Disabled", v);
    }

    public void onInit() {}
    protected void onEnable() {}
    protected void onDisable() {}
    public void onSave(JsonObject o) {}
    public void onLoad(JsonObject o) {}

    /** Text shown next to the name in the ArrayList. */
    public String getSuffix() {
        for (Setting<?> s : settings) if (s instanceof ModeSetting m) return m.get();
        return "";
    }

    protected BoolSetting bool(String n, boolean d) { return add(new BoolSetting(n, d)); }
    protected NumberSetting num(String n, double d, double min, double max, double step) { return add(new NumberSetting(n, d, min, max, step)); }
    protected ModeSetting mode(String n, String d, String... m) { return add(new ModeSetting(n, d, m)); }
    protected ColorSetting color(String n, int rgb) { return add(new ColorSetting(n, rgb)); }
    private <T extends Setting<?>> T add(T s) { settings.add(s); return s; }
}
