package com.flare.client.module.modules.combat;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import com.flare.client.util.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class AutoTrap extends Module {
    private final NumberSetting range = num("Range", 5, 2, 6, 0.5);
    private final NumberSetting blocks = num("Blocks/Tick", 3, 1, 8, 1);
    private final BoolSetting top = bool("Top", true), rotate = bool("Rotate", false);
    public AutoTrap() { super("AutoTrap", "Traps the nearest enemy in obsidian.", Category.COMBAT); }

    @Subscribe
    private void onTick(PlayerTickEvent e) {
        if (mc.player == null) return;
        PlayerEntity t = CombatUtil.nearestPlayer(range.d());
        if (t == null) return;
        int slot = InventoryUtil.findHotbar(s -> s.isOf(Items.OBSIDIAN));
        if (slot < 0) return;
        BlockPos feet = t.getBlockPos(); int placed = 0;
        for (int y = 0; y <= 1 && placed < blocks.i(); y++)
            for (Direction d : Direction.Type.HORIZONTAL) {
                if (placed >= blocks.i()) break;
                BlockPos p = feet.up(y).offset(d);
                if (BlockUtil.place(p, slot, rotate.is(), true)) placed++;
            }
        if (top.is() && placed < blocks.i() && BlockUtil.place(feet.up(2), slot, rotate.is(), true)) placed++;
    }
}
