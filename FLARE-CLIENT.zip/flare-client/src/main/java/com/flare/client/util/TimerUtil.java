package com.flare.client.util;
public class TimerUtil {
    private long last = System.currentTimeMillis();
    public boolean hasReached(long ms) { return System.currentTimeMillis() - last >= ms; }
    public void reset() { last = System.currentTimeMillis(); }
}
