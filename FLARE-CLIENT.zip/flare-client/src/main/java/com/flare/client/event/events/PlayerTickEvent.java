package com.flare.client.event.events;
import com.flare.client.event.Event;
/** Fired at the very start of ClientPlayerEntity#tick (before movement is simulated). */
public class PlayerTickEvent extends Event {}
