package com.flare.client.module.modules.combat;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import com.flare.client.util.InventoryUtil;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

public class AutoArmor extends Module {
    private final NumberSetting delay = num("Delay", 3, 0, 20, 1);
    private final BoolSetting inInventory = bool("Only In Inventory", false);
    private int tick;
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    public AutoArmor() { super("AutoArmor", "Automatically equips the best armor.", Category.COMBAT); }

    @Subscribe
    private void onTick(PlayerTickEvent e) {
        if (mc.player == null || !InventoryUtil.playerHandlerOpen()) return;
        if (inInventory.is() && !(mc.currentScreen instanceof net.minecraft.client.gui.screen.ingame.InventoryScreen)) return;
        if (++tick < delay.i()) return; tick = 0;
        for (int i = 0; i < 4; i++) {
            EquipmentSlot es = SLOTS[i];
            ItemStack worn = mc.player.getEquippedStack(es);
            float cur = InventoryUtil.armorScore(worn);
            int best = -1; float bs = cur + 0.05f;
            for (int s = 0; s < 36; s++) {
                ItemStack st = mc.player.getInventory().getStack(s);
                if (InventoryUtil.armorSlot(st) != es) continue;
                float sc = InventoryUtil.armorScore(st);
                if (sc > bs) { bs = sc; best = s; }
            }
            if (best < 0) continue;
            int armorSlotId = 5 + i, src = InventoryUtil.slotId(best);
            if (worn.isEmpty()) InventoryUtil.click(src, 0, SlotActionType.QUICK_MOVE);
            else { InventoryUtil.click(src, 0, SlotActionType.PICKUP); InventoryUtil.click(armorSlotId, 0, SlotActionType.PICKUP); InventoryUtil.click(src, 0, SlotActionType.PICKUP); }
            return;
        }
    }
}
