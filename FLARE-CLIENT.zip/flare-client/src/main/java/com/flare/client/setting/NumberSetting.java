package com.flare.client.setting;
import com.google.gson.*;
public class NumberSetting extends Setting<Double> {
    public final double min, max, step;
    public NumberSetting(String n, double d, double min, double max, double step) { super(n, d); this.min = min; this.max = max; this.step = step; }
    public double d() { return value; }
    public float f() { return value.floatValue(); }
    public int i() { return (int) Math.round(value); }
    @Override public void set(Double v) {
        double x = Math.max(min, Math.min(max, v));
        if (step > 0) x = Math.round(x / step) * step;
        value = Math.round(x * 10000.0) / 10000.0;
    }
    public JsonElement save() { return new JsonPrimitive(value); }
    public void load(JsonElement e) { set(e.getAsDouble()); }
}
