package com.flare.client.module.modules.player;

import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.BoolSetting;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;

public class ChatSuffix extends Module {
    private final BoolSetting suffix = bool("Suffix", true), fancy = bool("Fancy Text", false);
    private static final String NORMAL = "abcdefghijklmnopqrstuvwxyz", SMALL = "ᴀʙᴄᴅᴇғɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ";
    public ChatSuffix() { super("ChatSuffix", "Adds a FLARE suffix and/or fancy small-caps to your chat.", Category.PLAYER); }

    @Override public void onInit() {
        ClientSendMessageEvents.MODIFY_CHAT.register(msg -> {
            if (!isEnabled() || msg.startsWith("/") || msg.startsWith(".") || msg.startsWith("!")) return msg;
            String out = msg;
            if (fancy.is()) { StringBuilder sb = new StringBuilder(); for (char c : msg.toCharArray()) { int i = NORMAL.indexOf(Character.toLowerCase(c)); sb.append(i >= 0 ? SMALL.charAt(i) : c); } out = sb.toString(); }
            if (suffix.is()) out += " ⏐ ꜰʟᴀʀᴇ";
            return out.length() > 256 ? msg : out;
        });
    }
}
