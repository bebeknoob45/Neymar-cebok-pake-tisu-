package com.flare.client.module.modules.movement;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.ModeSetting;
import net.minecraft.fluid.FluidState;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class Jesus extends Module {
    private final ModeSetting mode = mode("Mode", "Solid", "Solid", "Dolphin");
    public Jesus() { super("Jesus", "Walk on water and lava.", Category.MOVEMENT); }

    @Subscribe
    private void onTick(PlayerTickEvent e) {
        var p = mc.player; if (p == null || p.isSneaking()) return;
        Vec3d v = p.getVelocity();
        if (mode.is("Dolphin")) { if (p.isTouchingWater() || p.isInLava()) p.setVelocity(v.x, 0.11, v.z); return; }
        if (mc.options.jumpKey.isPressed()) return;
        BlockPos feet = BlockPos.ofFloored(p.getX(), p.getY(), p.getZ());
        FluidState fs = mc.world.getFluidState(feet);
        if (!fs.isEmpty() && (fs.isIn(FluidTags.WATER) || fs.isIn(FluidTags.LAVA)) && mc.world.getFluidState(feet.up()).isEmpty()) {
            double top = feet.getY() + fs.getHeight(mc.world, feet);
            if (p.getY() <= top + 0.1) { p.setVelocity(v.x, 0, v.z); p.setPosition(p.getX(), top, p.getZ()); p.setOnGround(true); }
        }
    }
}
