package com.flare.client.module.modules.player;

import com.flare.client.FriendManager;
import com.flare.client.event.Subscribe;
import com.flare.client.event.events.TickEvent;
import com.flare.client.gui.NotificationManager;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.BoolSetting;
import com.flare.client.util.InventoryUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

public class MiddleClick extends Module {
    private final BoolSetting pearl = bool("Pearl", true), friend = bool("Friend", true);
    private boolean down;
    public MiddleClick() { super("MiddleClick", "Middle mouse: friend a player you look at, or throw a pearl.", Category.PLAYER); }

    @Subscribe
    private void onTick(TickEvent.Pre e) {
        if (mc.player == null || mc.currentScreen != null) return;
        boolean now = GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;
        boolean click = now && !down; down = now;
        if (!click) return;
        if (friend.is() && mc.targetedEntity instanceof PlayerEntity p) {
            FriendManager.toggle(p.getName().getString());
            NotificationManager.push("Friends", p.getName().getString() + (FriendManager.isFriend(p.getName().getString()) ? " added" : " removed"), true);
            return;
        }
        if (pearl.is()) {
            int slot = InventoryUtil.findHotbar(s -> s.isOf(Items.ENDER_PEARL));
            if (slot < 0) return;
            int prev = mc.player.getInventory().selectedSlot;
            mc.player.getInventory().selectedSlot = slot;
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            mc.player.swingHand(Hand.MAIN_HAND);
            mc.player.getInventory().selectedSlot = prev;
        }
    }
}
