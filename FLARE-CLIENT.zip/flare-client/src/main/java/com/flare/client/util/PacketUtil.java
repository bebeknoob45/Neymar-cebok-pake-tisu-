package com.flare.client.util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
public final class PacketUtil {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public static volatile boolean silent;
    public static void send(Packet<?> p) { ClientPlayNetworkHandler h = mc.getNetworkHandler(); if (h != null) h.sendPacket(p); }
    /** Sends a packet without it passing through the event bus (used when flushing queues). */
    public static void sendSilent(Packet<?> p) { silent = true; try { send(p); } finally { silent = false; } }
    public static void pos(double x, double y, double z, boolean ground) {
        send(new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, ground, mc.player.horizontalCollision));
    }
    public static void look(float yaw, float pitch, boolean ground) {
        send(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, ground, mc.player.horizontalCollision));
    }
}
