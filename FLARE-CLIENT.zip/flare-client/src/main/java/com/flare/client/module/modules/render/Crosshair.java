package com.flare.client.module.modules.render;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.Render2DEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import com.flare.client.util.*;
import net.minecraft.client.gui.DrawContext;

public class Crosshair extends Module {
    private final ColorSetting color = color("Color", 0xFF6B00);
    private final NumberSetting size = num("Size", 5, 1, 15, 1), gap = num("Gap", 3, 0, 12, 1), thickness = num("Thickness", 1, 1, 4, 1);
    private final BoolSetting dot = bool("Dot", false), outline = bool("Outline", true), dynamic = bool("Dynamic Gap", true);
    public Crosshair() { super("Crosshair", "Customizable crosshair.", Category.RENDER); }

    @Subscribe
    private void onRender(Render2DEvent e) {
        if (mc.options.hudHidden || !mc.options.getPerspective().isFirstPerson() || mc.currentScreen != null) return;
        DrawContext c = e.ctx; float cx = c.getScaledWindowWidth() / 2f, cy = c.getScaledWindowHeight() / 2f;
        float g = gap.f() + (dynamic.is() && mc.player != null && (MoveUtil.isMoving() || !mc.player.isOnGround()) ? 2 : 0), s = size.f(), t = thickness.f();
        int col = color.getColor() | 0xFF000000;
        float[][] bars = {{cx - g - s, cy - t / 2f, s, t}, {cx + g, cy - t / 2f, s, t}, {cx - t / 2f, cy - g - s, t, s}, {cx - t / 2f, cy + g, t, s}};
        for (float[] b : bars) { if (outline.is()) Draw.rect(c, b[0] - 1, b[1] - 1, b[2] + 2, b[3] + 2, 0xFF000000); }
        for (float[] b : bars) Draw.rect(c, b[0], b[1], b[2], b[3], col);
        if (dot.is()) { Draw.rect(c, cx - 1.5f, cy - 1.5f, 3, 3, 0xFF000000); Draw.rect(c, cx - 0.5f, cy - 0.5f, 1.5f, 1.5f, col); }
    }
}
