package com.flare.client.event.events;
import com.flare.client.event.Event;
public class TickEvent {
    public static class Pre extends Event {}
    public static class Post extends Event {}
}
