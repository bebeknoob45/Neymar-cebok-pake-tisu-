package com.flare.client.module.modules.movement;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.NumberSetting;
import net.minecraft.entity.attribute.EntityAttributes;

public class Step extends Module {
    private final NumberSetting height = num("Height", 1.0, 0.6, 2.5, 0.1);
    public Step() { super("Step", "Step up blocks without jumping.", Category.MOVEMENT); }
    @Override public String getSuffix() { return String.valueOf(height.d()); }
    @Subscribe private void onTick(PlayerTickEvent e) { set(height.d()); }
    @Override protected void onDisable() { set(0.6); }
    private void set(double v) { if (mc.player != null) { var a = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT); if (a != null) a.setBaseValue(v); } }
}
