package com.flare.client.module.modules.render;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

public class Fullbright extends Module {
    public Fullbright() { super("Fullbright", "See clearly in the dark.", Category.RENDER); }
    @Subscribe private void onTick(PlayerTickEvent e) {
        if (mc.player == null) return;
        var cur = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (cur == null || cur.getDuration() < 400) mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 32767, 0, false, false, false));
    }
    @Override protected void onDisable() { if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION); }
}
