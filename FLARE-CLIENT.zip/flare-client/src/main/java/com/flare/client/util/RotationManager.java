package com.flare.client.util;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.MotionEvent;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Silent (server-side) rotation system. Modules request a rotation; right before movement packets are
 * built the player's yaw/pitch is swapped, then restored afterwards, so the camera never moves.
 */
public final class RotationManager {
    public static final RotationManager INSTANCE = new RotationManager();
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private float yaw, pitch, savedYaw, savedPitch;
    private int hold; private boolean active, spoofing;
    public float serverYaw, serverPitch;

    public void rotate(float y, float p, int holdTicks) { yaw = y; pitch = MathHelper.clamp(p, -90, 90); hold = holdTicks; active = true; }
    public boolean isActive() { return active; }
    public float curYaw() { return active ? yaw : mc.player.getYaw(); }
    public float curPitch() { return active ? pitch : mc.player.getPitch(); }

    @Subscribe
    private void onMotion(MotionEvent e) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        if (e.pre) {
            if (active) { savedYaw = p.getYaw(); savedPitch = p.getPitch(); p.setYaw(yaw); p.setPitch(pitch); spoofing = true; }
        } else {
            if (spoofing) { p.setYaw(savedYaw); p.setPitch(savedPitch); spoofing = false; serverYaw = yaw; serverPitch = pitch; if (--hold <= 0) active = false; }
            else { serverYaw = p.getYaw(); serverPitch = p.getPitch(); }
        }
    }

    /** One-shot packet rotation sent immediately (use right before an interaction packet). */
    public void snap(float y, float p) {
        float[] r = gcd(new float[]{y, MathHelper.clamp(p, -90, 90)}, serverYaw, serverPitch);
        PacketUtil.look(r[0], r[1], mc.player.isOnGround());
        serverYaw = r[0]; serverPitch = r[1];
    }
    public void snapTo(Vec3d point) { float[] r = toRotation(mc.player.getEyePos(), point); snap(r[0], r[1]); }

    public static float[] toRotation(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        return new float[]{(float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0), (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)))};
    }

    public static float[] smooth(float cy, float cp, float ty, float tp, float speed) {
        float dy = MathHelper.wrapDegrees(ty - cy), dp = tp - cp, dist = (float) Math.hypot(dy, dp);
        if (dist > speed && dist > 1e-4f) { float f = speed / dist; dy *= f; dp *= f; }
        return new float[]{cy + dy, MathHelper.clamp(cp + dp, -90, 90)};
    }

    /** Snap rotation deltas to the mouse sensitivity grid (mimics real mouse input). */
    public static float[] gcd(float[] r, float py, float pp) {
        double f = mc.options.getMouseSensitivity().getValue() * 0.6 + 0.2, g = f * f * f * 8.0 * 0.15;
        float y = py + (float) (Math.round((r[0] - py) / g) * g), p = pp + (float) (Math.round((r[1] - pp) / g) * g);
        return new float[]{y, MathHelper.clamp(p, -90, 90)};
    }
}
