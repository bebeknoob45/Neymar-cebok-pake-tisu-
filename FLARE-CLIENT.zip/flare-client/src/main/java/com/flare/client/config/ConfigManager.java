package com.flare.client.config;

import com.flare.client.FlareClient;
import com.flare.client.module.Module;
import com.flare.client.module.modules.client.ClickGuiModule;
import com.flare.client.setting.Setting;
import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;
import java.util.*;

public final class ConfigManager {
    public static final Path DIR = FabricLoader.getInstance().getGameDir().resolve("flare/configs");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static boolean save(String name) {
        try {
            Files.createDirectories(DIR);
            JsonObject root = new JsonObject(), mods = new JsonObject();
            for (Module m : FlareClient.modules.all()) {
                JsonObject o = new JsonObject(), st = new JsonObject(), extra = new JsonObject();
                o.addProperty("enabled", m.isEnabled() && !(m instanceof ClickGuiModule));
                o.addProperty("bind", m.bind.key());
                for (Setting<?> s : m.getSettings()) st.add(s.name, s.save());
                o.add("settings", st);
                m.onSave(extra); o.add("extra", extra);
                mods.add(m.getName(), o);
            }
            root.add("modules", mods);
            Files.writeString(DIR.resolve(clean(name) + ".json"), GSON.toJson(root));
            return true;
        } catch (Exception e) { FlareClient.LOG.error("save config", e); return false; }
    }

    public static boolean load(String name) {
        try {
            Path p = DIR.resolve(clean(name) + ".json");
            if (!Files.exists(p)) return false;
            JsonObject mods = JsonParser.parseString(Files.readString(p)).getAsJsonObject().getAsJsonObject("modules");
            for (Module m : FlareClient.modules.all()) {
                if (!mods.has(m.getName())) continue;
                JsonObject o = mods.getAsJsonObject(m.getName());
                try {
                    if (o.has("bind")) m.bind.load(o.get("bind"));
                    if (o.has("settings")) for (Setting<?> s : m.getSettings()) if (o.getAsJsonObject("settings").has(s.name)) {
                        try { s.load(o.getAsJsonObject("settings").get(s.name)); } catch (Exception ignored) {}
                    }
                    if (o.has("extra")) m.onLoad(o.getAsJsonObject("extra"));
                    if (!(m instanceof ClickGuiModule) && o.has("enabled")) m.setEnabled(o.get("enabled").getAsBoolean(), false);
                } catch (Exception ex) { FlareClient.LOG.warn("config " + m.getName(), ex); }
            }
            return true;
        } catch (Exception e) { FlareClient.LOG.error("load config", e); return false; }
    }

    public static boolean delete(String name) { try { return Files.deleteIfExists(DIR.resolve(clean(name) + ".json")); } catch (Exception e) { return false; } }

    public static List<String> list() {
        List<String> l = new ArrayList<>();
        try { if (Files.exists(DIR)) try (var s = Files.list(DIR)) { s.forEach(f -> { String n = f.getFileName().toString(); if (n.endsWith(".json")) l.add(n.substring(0, n.length() - 5)); }); } } catch (Exception ignored) {}
        Collections.sort(l);
        return l;
    }
    private static String clean(String n) { return n.replaceAll("[^a-zA-Z0-9_\\-]", "_"); }
}
