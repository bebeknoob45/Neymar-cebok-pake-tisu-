package com.flare.client;

import com.google.gson.*;
import com.mojang.authlib.GameProfile;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.RecordComponent;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/**
 * Custom Identity with several saved accounts you can switch between (offline / cracked servers).
 * The nickname goes into the game session before you join. A skin PNG changes how YOU see your character;
 * other players only see it if the server supports it (e.g. SkinsRestorer). Nothing is cloned from other accounts.
 */
public final class IdentityManager {
    public static final class Profile {
        public String name, skin; public boolean slim;
        public Profile(String n, String s, boolean sl) { name = n; skin = s; slim = sl; }
    }

    private static final Path DIR = FabricLoader.getInstance().getGameDir().resolve("flare");
    public static final Path SKINS = DIR.resolve("skins");
    private static final Path FILE = DIR.resolve("identity.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Identifier SKIN_ID = Identifier.of("flare", "identity_skin");

    public static final List<Profile> profiles = new ArrayList<>();
    public static int active = -1;
    /** Values of the active profile (used by the session + skin mixin). */
    public static String name = "", skin = ""; public static boolean slim;
    private static Session origSession; private static GameProfile origProfile;
    private static boolean textureReady; private static String textureFor = "";
    private static Object lastIn, lastOut;

    public static void load() {
        try {
            if (!Files.exists(FILE)) return;
            JsonObject o = GSON.fromJson(Files.readString(FILE), JsonObject.class);
            profiles.clear();
            if (o.has("profiles")) for (JsonElement e : o.getAsJsonArray("profiles")) {
                JsonObject p = e.getAsJsonObject();
                profiles.add(new Profile(p.get("name").getAsString(), p.has("skin") ? p.get("skin").getAsString() : "", p.has("slim") && p.get("slim").getAsBoolean()));
            } else if (o.has("name") && !o.get("name").getAsString().isEmpty()) { // old 1.5.1 format
                profiles.add(new Profile(o.get("name").getAsString(), o.has("skin") ? o.get("skin").getAsString() : "", o.has("slim") && o.get("slim").getAsBoolean()));
                active = 0;
            }
            if (o.has("active")) active = o.get("active").getAsInt();
            if (active >= profiles.size()) active = -1;
            sync();
        } catch (Exception ignored) {}
    }

    public static void save() {
        try {
            Files.createDirectories(DIR);
            JsonObject o = new JsonObject(); JsonArray a = new JsonArray();
            for (Profile p : profiles) { JsonObject j = new JsonObject(); j.addProperty("name", p.name); j.addProperty("skin", p.skin); j.addProperty("slim", p.slim); a.add(j); }
            o.add("profiles", a); o.addProperty("active", active);
            Files.writeString(FILE, GSON.toJson(o));
        } catch (Exception ignored) {}
    }

    private static void sync() {
        if (active >= 0 && active < profiles.size()) { Profile p = profiles.get(active); name = p.name; skin = p.skin; slim = p.slim; }
        else { name = ""; skin = ""; slim = false; }
        changed();
    }

    public static List<String> listSkins() {
        List<String> l = new ArrayList<>();
        try { Files.createDirectories(SKINS); try (var s = Files.list(SKINS)) { s.forEach(f -> { String n = f.getFileName().toString(); if (n.toLowerCase().endsWith(".png")) l.add(n); }); } } catch (Exception ignored) {}
        Collections.sort(l); return l;
    }

    public static boolean validName(String n) { return n.matches("[A-Za-z0-9_]{3,16}"); }

    /** Switch to a saved account (index into profiles) or back to the original account (-1). */
    public static boolean switchTo(int idx) {
        active = idx; sync(); save();
        return idx < 0 ? restoreOriginal() : applyName();
    }

    /** Applies the active profile's nickname to the game session (offline mode UUID). */
    public static boolean applyName() {
        if (name.isEmpty()) return false;
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            Session old = mc.getSession();
            if (origSession == null) { origSession = old; origProfile = mc.getGameProfile(); }
            UUID id = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
            Session s = new Session(name, id, old.getAccessToken(), Optional.empty(), Optional.empty(), Session.AccountType.LEGACY);
            setByType(mc, Session.class, s);
            setByType(mc, GameProfile.class, new GameProfile(id, name));
            return true;
        } catch (Throwable t) { FlareClient.LOG.error("apply identity", t); return false; }
    }

    private static boolean restoreOriginal() {
        if (origSession == null) return true; // never changed in this run, already original
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            setByType(mc, Session.class, origSession);
            if (origProfile != null) setByType(mc, GameProfile.class, origProfile);
            return true;
        } catch (Throwable t) { FlareClient.LOG.error("restore identity", t); return false; }
    }

    private static void setByType(Object target, Class<?> type, Object value) throws Exception {
        for (Field f : target.getClass().getDeclaredFields()) if (f.getType() == type) { f.setAccessible(true); f.set(target, value); }
    }

    public static void changed() { textureReady = false; lastIn = null; lastOut = null; }

    private static boolean ensureTexture() {
        if (skin.isEmpty()) return false;
        if (textureReady && textureFor.equals(skin)) return true;
        try (InputStream in = Files.newInputStream(SKINS.resolve(skin))) {
            NativeImage img = NativeImage.read(in);
            if (img.getWidth() != 64 || img.getHeight() != 64) { img.close(); FlareClient.LOG.warn("Skin must be 64x64"); skin = ""; return false; }
            MinecraftClient.getInstance().getTextureManager().registerTexture(SKIN_ID, new NativeImageBackedTexture(img));
            textureReady = true; textureFor = skin; lastIn = null; lastOut = null; return true;
        } catch (Throwable t) { FlareClient.LOG.error("skin load", t); skin = ""; return false; }
    }

    /** Called from the skin mixin. Returns a replacement SkinTextures (as Object) or null to keep the original. */
    public static Object overrideSkin(Object original) {
        if (original == null || skin.isEmpty() || !ensureTexture()) return null;
        if (original == lastIn) return lastOut;
        try {
            Class<?> c = original.getClass(); RecordComponent[] rc = c.getRecordComponents();
            Object[] v = new Object[rc.length];
            for (int i = 0; i < rc.length; i++) { rc[i].getAccessor().setAccessible(true); v[i] = rc[i].getAccessor().invoke(original); }
            v[0] = SKIN_ID; v[1] = null;
            @SuppressWarnings({"unchecked", "rawtypes"}) Object model = Enum.valueOf((Class) rc[4].getType(), slim ? "SLIM" : "WIDE");
            v[4] = model;
            for (Constructor<?> k : c.getDeclaredConstructors()) if (k.getParameterCount() == rc.length) { k.setAccessible(true); lastIn = original; lastOut = k.newInstance(v); return lastOut; }
        } catch (Throwable t) { FlareClient.LOG.error("skin override", t); skin = ""; }
        return null;
    }
}
