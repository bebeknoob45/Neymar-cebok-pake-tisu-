package com.flare.client.module.modules.combat;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import com.flare.client.util.*;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class HoleFiller extends Module {
    private final NumberSetting range = num("Range", 4.5, 2, 6, 0.5);
    private final NumberSetting delay = num("Delay", 2, 0, 10, 1);
    private final NumberSetting enemyRange = num("Enemy Range", 3, 1, 8, 0.5);
    private final BoolSetting onlyNear = bool("Only Near Enemy", true), rotate = bool("Rotate", false);
    private int tick;
    public HoleFiller() { super("HoleFiller", "Fills safe holes so enemies cannot hide in them.", Category.COMBAT); }

    @Subscribe
    private void onTick(PlayerTickEvent e) {
        if (mc.player == null || ++tick < delay.i()) return;
        int slot = InventoryUtil.findHotbar(s -> s.isOf(Items.OBSIDIAN));
        if (slot < 0) return;
        int r = (int) Math.ceil(range.d()); BlockPos o = mc.player.getBlockPos();
        for (int x = -r; x <= r; x++) for (int y = -2; y <= 2; y++) for (int z = -r; z <= r; z++) {
            BlockPos p = o.add(x, y, z);
            if (mc.player.getEyePos().distanceTo(p.toCenterPos()) > range.d() || !isHole(p)) continue;
            if (onlyNear.is()) {
                boolean near = false;
                for (PlayerEntity pl : mc.world.getPlayers()) if (pl != mc.player && !CombatUtil.isFriend(pl) && pl.getPos().distanceTo(p.toCenterPos()) <= enemyRange.d()) near = true;
                if (!near) continue;
            }
            if (BlockUtil.place(p, slot, rotate.is(), true)) { tick = 0; return; }
        }
    }

    private boolean isHole(BlockPos p) {
        if (!mc.world.isAir(p) || !mc.world.isAir(p.up()) || !mc.world.isAir(p.up(2))) return false;
        if (mc.world.getBlockState(p.down()).isAir()) return false;
        for (Direction d : Direction.Type.HORIZONTAL) {
            var s = mc.world.getBlockState(p.offset(d));
            if (!s.isOf(Blocks.OBSIDIAN) && !s.isOf(Blocks.BEDROCK)) return false;
        }
        return true;
    }
}
