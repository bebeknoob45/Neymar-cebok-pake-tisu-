package com.flare.client.module.modules.player;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import com.flare.client.util.InventoryUtil;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import java.util.function.Predicate;

/** AutoSort: arranges your hotbar into a preset while your inventory is open. Slot 0 = unused. */
public class InventoryManager extends Module {
    private final NumberSetting sword = num("Sword Slot", 1, 0, 9, 1), crystal = num("Crystal Slot", 2, 0, 9, 1), pearl = num("Pearl Slot", 3, 0, 9, 1),
            gapple = num("Gapple Slot", 4, 0, 9, 1), obsidian = num("Obsidian Slot", 5, 0, 9, 1);
    private final NumberSetting delay = num("Delay", 2, 0, 10, 1);
    private final BoolSetting onlyInv = bool("Only In Inventory", true);
    private int tick;
    public InventoryManager() { super("InventoryManager", "AutoSort: arranges your hotbar into a preset.", Category.PLAYER); }

    @Subscribe
    private void onTick(PlayerTickEvent e) {
        if (mc.player == null || !InventoryUtil.playerHandlerOpen()) return;
        if (onlyInv.is() && !(mc.currentScreen instanceof InventoryScreen)) return;
        if (++tick < delay.i()) return; tick = 0;
        if (sort(sword.i(), s -> s.isIn(ItemTags.SWORDS))) return;
        if (sort(crystal.i(), s -> s.isOf(Items.END_CRYSTAL))) return;
        if (sort(pearl.i(), s -> s.isOf(Items.ENDER_PEARL))) return;
        if (sort(gapple.i(), s -> s.isOf(Items.ENCHANTED_GOLDEN_APPLE) || s.isOf(Items.GOLDEN_APPLE))) return;
        sort(obsidian.i(), s -> s.isOf(Items.OBSIDIAN));
    }

    private boolean sort(int slot, Predicate<ItemStack> p) {
        if (slot <= 0) return false;
        int hb = slot - 1;
        if (p.test(mc.player.getInventory().getStack(hb))) return false;
        int src = -1;
        for (int i = 9; i < 36 && src < 0; i++) if (p.test(mc.player.getInventory().getStack(i))) src = i;
        if (src < 0) return false;
        InventoryUtil.swapWithHotbar(src, hb);
        return true;
    }
}
