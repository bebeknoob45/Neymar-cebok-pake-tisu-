package com.flare.client.gui;

import com.flare.client.IdentityManager;
import com.flare.client.IdentityManager.Profile;
import com.flare.client.util.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.List;

/** Main-menu screen: manage several custom (offline) accounts and switch between them. */
public class IdentityScreen extends Screen {
    private final Screen parent;
    private int sel = -1;                   // -1 = new, 0 = original account, i+1 = profile i
    private String nick = "", skin = ""; private boolean slim; private String status = "";
    private List<String> skins; private float scrollA, scrollS;
    private final Anim fade = new Anim(0, 12);
    private static final String[] BTN = {"SAVE", "SWITCH", "NEW", "DELETE", "BACK"};

    public IdentityScreen(Screen parent) {
        super(Text.literal("Custom Identity")); this.parent = parent; skins = IdentityManager.listSkins();
        select(IdentityManager.active >= 0 ? IdentityManager.active + 1 : 0);
    }

    private void select(int i) {
        sel = i;
        if (i >= 1 && i - 1 < IdentityManager.profiles.size()) { Profile p = IdentityManager.profiles.get(i - 1); nick = p.name; skin = p.skin; slim = p.slim; }
        else if (i == -1) { nick = ""; skin = ""; slim = false; }
    }

    private float px() { return width / 2f - 165; }
    private static final float PY = 14, PW = 330;
    private float ph() { return Math.min(height - 28, 250); }
    private float bodyH() { return ph() - 38 - 28; }

    private List<String> accountRows() {
        List<String> r = new ArrayList<>(); r.add("(original account)");
        for (int i = 0; i < IdentityManager.profiles.size(); i++) r.add((i == IdentityManager.active ? "* " : "") + IdentityManager.profiles.get(i).name);
        return r;
    }
    private List<String> skinRows() { List<String> r = new ArrayList<>(); r.add(""); r.addAll(skins); return r; }

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        Draw.alpha = fade.update(1);
        ctx.fill(0, 0, width, height, 0xFF0A0A0A);
        ctx.fillGradient(0, height / 2, width, height, 0x00FF6B00, 0x40FF6B00);
        float x = px(), y = PY, w = PW, h = ph();
        Draw.glow(ctx, x, y, w, h, 4, ColorUtil.ORANGE, 0.5f);
        Draw.rrect(ctx, x, y, w, h, 4, 0xF00A0A0A);
        Draw.gradH(ctx, x, y + 20, w, 2, ColorUtil.ORANGE, ColorUtil.ORANGE2);
        Draw.text(ctx, "CUSTOM IDENTITY", x + 8, y + 7, ColorUtil.ORANGE2, true);
        String info = "Offline / cracked servers only";
        Draw.text(ctx, info, x + w - 8 - Draw.width(info), y + 7, 0xFF8A8A8A, false);

        // left: accounts
        float lx = x + 8, lw = 118, ly = y + 38;
        Draw.text(ctx, "ACCOUNTS (* = active)", lx, y + 26, 0xFFB0B0B0, false);
        list(ctx, mx, my, lx, ly, lw, bodyH(), accountRows(), scrollA, sel);
        // right: editor
        float rx = x + 136, rw = w - 144;
        boolean editable = sel != 0;
        Draw.text(ctx, "Nickname (3-16: letters, numbers, _)", rx, y + 26, 0xFFB0B0B0, false);
        Draw.rrect(ctx, rx, y + 37, rw, 15, 3, 0xFF161616);
        Draw.outline(ctx, rx, y + 37, rw, 15, ColorUtil.alpha(ColorUtil.ORANGE, editable ? 170 : 60));
        boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
        Draw.text(ctx, sel == 0 ? "(your real launcher name)" : nick.isEmpty() ? "Your nickname..." : nick + (blink ? "_" : ""), rx + 5, y + 41, nick.isEmpty() || sel == 0 ? 0xFF666666 : 0xFFFFFFFF, false);
        Draw.text(ctx, "Skin (64x64 .png in flare/skins)", rx, y + 58, 0xFFB0B0B0, false);
        float sy = y + 69, sh = bodyH() - 31;
        List<String> sr = skinRows(); int selSkin = skin.isEmpty() ? 0 : Math.max(0, sr.indexOf(skin));
        list(ctx, mx, my, rx, sy, rw, sh, sr, scrollS, editable ? selSkin : -1);
        float mby = sy + sh + 3;
        button(ctx, mx, my, rx, mby, rw, "Model: " + (slim ? "Slim (Alex)" : "Wide (Steve)"), 15);

        // bottom buttons
        float bw = (w - 16 - 4 * 4) / 5f, by = y + h - 22;
        for (int i = 0; i < 5; i++) button(ctx, mx, my, x + 8 + i * (bw + 4), by, bw, BTN[i], 15);
        Draw.text(ctx, status, width / 2f - Draw.width(status) / 2f, y + h + 4, ColorUtil.ORANGE2, false);
        String n = "Skin is shown to you; others see it only if the server supports it.";
        Draw.text(ctx, n, width / 2f - Draw.width(n) / 2f, height - 11, 0xFF666666, false);
        Draw.alpha = 1f;
    }

    private void list(DrawContext ctx, int mx, int my, float x, float y, float w, float h, List<String> rows, float scroll, int selected) {
        Draw.rect(ctx, x, y, w, h, 0xFF0E0E0E);
        ctx.enableScissor((int) x, (int) y, (int) (x + w), (int) (y + h));
        for (int i = 0; i < rows.size(); i++) {
            float ry = y + i * 13 - scroll; boolean s = i == selected, hov = Draw.hover(mx, my, x, ry, w, 12) && my >= y && my <= y + h;
            Draw.rect(ctx, x, ry, w, 12, s ? ColorUtil.alpha(ColorUtil.ORANGE, 170) : hov ? 0xFF1E1E1E : 0x00000000);
            String t = rows.get(i).isEmpty() ? "(default skin)" : rows.get(i);
            Draw.text(ctx, t, x + 4, ry + 2, s ? 0xFF0A0A0A : 0xFFFFFFFF, false);
        }
        ctx.disableScissor();
    }

    private void button(DrawContext ctx, int mx, int my, float x, float y, float w, String t, float h) {
        boolean hov = Draw.hover(mx, my, x, y, w, h);
        Draw.rrect(ctx, x, y, w, h, 3, hov ? ColorUtil.ORANGE : 0xFF1C1C1C);
        Draw.text(ctx, t, x + (w - Draw.width(t)) / 2f, y + 4, hov ? 0xFF0A0A0A : 0xFFFFFFFF, false);
    }

    @Override public boolean mouseClicked(double mx, double my, int btn) {
        float x = px(), y = PY, w = PW, h = ph();
        float lx = x + 8, lw = 118, ly = y + 38, rx = x + 136, rw = w - 144, sy = y + 69, sh = bodyH() - 31;
        List<String> ar = accountRows();
        if (my >= ly && my <= ly + bodyH()) for (int i = 0; i < ar.size(); i++) if (Draw.hover(mx, my, lx, ly + i * 13 - scrollA, lw, 12)) { select(i); return true; }
        if (sel != 0) {
            List<String> sr = skinRows();
            if (my >= sy && my <= sy + sh) for (int i = 0; i < sr.size(); i++) if (Draw.hover(mx, my, rx, sy + i * 13 - scrollS, rw, 12)) { skin = i == 0 ? "" : sr.get(i); return true; }
            if (Draw.hover(mx, my, rx, sy + sh + 3, rw, 15)) { slim = !slim; return true; }
        }
        float bw = (w - 16 - 16) / 5f, by = y + h - 22;
        for (int i = 0; i < 5; i++) if (Draw.hover(mx, my, x + 8 + i * (bw + 4), by, bw, 15)) { action(i); return true; }
        return false;
    }

    private boolean save() {
        if (sel == 0) { status = "Original account cannot be edited"; return false; }
        if (!IdentityManager.validName(nick)) { status = "Invalid nickname (3-16 letters, numbers, _)"; return false; }
        if (sel >= 1 && sel - 1 < IdentityManager.profiles.size()) { Profile p = IdentityManager.profiles.get(sel - 1); p.name = nick; p.skin = skin; p.slim = slim; }
        else { IdentityManager.profiles.add(new Profile(nick, skin, slim)); sel = IdentityManager.profiles.size(); }
        IdentityManager.save();
        if (sel - 1 == IdentityManager.active) { IdentityManager.switchTo(IdentityManager.active); }
        status = "Saved '" + nick + "'"; return true;
    }

    private void action(int i) {
        switch (i) {
            case 0 -> save();
            case 1 -> {
                if (sel == 0) { status = IdentityManager.switchTo(-1) ? "Back to your original account" : "Could not switch"; return; }
                if (!save()) return;
                status = IdentityManager.switchTo(sel - 1) ? "Switched! You will join servers as " + nick : "Could not switch";
            }
            case 2 -> { select(-1); status = "New account: type a nickname, then SAVE"; }
            case 3 -> {
                if (sel < 1 || sel - 1 >= IdentityManager.profiles.size()) { status = "Select a saved account first"; return; }
                int idx = sel - 1; IdentityManager.profiles.remove(idx);
                if (IdentityManager.active == idx) { IdentityManager.switchTo(-1); } else if (IdentityManager.active > idx) IdentityManager.active--;
                IdentityManager.save(); select(0); status = "Deleted";
            }
            default -> client.setScreen(parent);
        }
    }

    @Override public boolean mouseScrolled(double mx, double my, double h, double v) {
        float x = px();
        if (mx < x + 134) scrollA = Math.max(0, Math.min(Math.max(0, accountRows().size() * 13 - bodyH()), scrollA - (float) v * 13));
        else scrollS = Math.max(0, Math.min(Math.max(0, skinRows().size() * 13 - (bodyH() - 31)), scrollS - (float) v * 13));
        return true;
    }
    @Override public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ESCAPE) { client.setScreen(parent); return true; }
        if (key == GLFW.GLFW_KEY_BACKSPACE && sel != 0 && !nick.isEmpty()) { nick = nick.substring(0, nick.length() - 1); return true; }
        if (key == GLFW.GLFW_KEY_ENTER) { action(1); return true; }
        return super.keyPressed(key, scan, mods);
    }
    @Override public boolean charTyped(char c, int mods) { if (sel != 0 && nick.length() < 16 && (Character.isLetterOrDigit(c) || c == '_') && c < 128) { nick += c; return true; } return false; }
}
