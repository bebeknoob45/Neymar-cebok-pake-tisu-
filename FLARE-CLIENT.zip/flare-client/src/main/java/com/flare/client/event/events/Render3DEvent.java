package com.flare.client.event.events;
import com.flare.client.event.Event;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
public class Render3DEvent extends Event {
    public final Matrix4f view; public final Camera camera; public final Vec3d cam; public final float delta;
    public Render3DEvent(Matrix4f view, Camera camera, float delta) {
        this.view = view; this.camera = camera; this.cam = camera.getPos(); this.delta = delta;
    }
}
